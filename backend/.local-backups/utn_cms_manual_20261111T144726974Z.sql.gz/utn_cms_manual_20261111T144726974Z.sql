-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: utn_cms
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `utn_cms`
--

/*!40000 DROP DATABASE IF EXISTS `utn_cms`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `utn_cms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `utn_cms`;

--
-- Table structure for table `agreements`
--

DROP TABLE IF EXISTS `agreements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agreements` (
  `id_agreement` int NOT NULL AUTO_INCREMENT,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `sign_date` date DEFAULT NULL,
  `signatory` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id_agreement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agreements`
--

LOCK TABLES `agreements` WRITE;
/*!40000 ALTER TABLE `agreements` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id_asset` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id_asset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit`
--

DROP TABLE IF EXISTS `audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit` (
  `id_audit` int NOT NULL AUTO_INCREMENT,
  `audit_table` varchar(255) DEFAULT NULL,
  `audit_action` varchar(255) DEFAULT NULL,
  `audit_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_in_charge` int DEFAULT NULL,
  PRIMARY KEY (`id_audit`),
  KEY `user_in_charge` (`user_in_charge`),
  CONSTRAINT `audit_ibfk_1` FOREIGN KEY (`user_in_charge`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit`
--

LOCK TABLES `audit` WRITE;
/*!40000 ALTER TABLE `audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate` (
  `certificate_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `year_of_issue` int NOT NULL,
  `is_international` tinyint(1) NOT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `signatory_type` varchar(50) DEFAULT 'instructor',
  `signatory_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`certificate_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `certificate_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate`
--

LOCK TABLES `certificate` WRITE;
/*!40000 ALTER TABLE `certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter`
--

DROP TABLE IF EXISTS `chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter` (
  `chapter_id` int NOT NULL AUTO_INCREMENT,
  `chapter_name` varchar(255) NOT NULL,
  `hours` int DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `main_topics` text,
  `modality` varchar(100) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `session_start_time` time DEFAULT NULL,
  `session_end_time` time DEFAULT NULL,
  PRIMARY KEY (`chapter_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter`
--

LOCK TABLES `chapter` WRITE;
/*!40000 ALTER TABLE `chapter` DISABLE KEYS */;
INSERT INTO `chapter` VALUES (32,'Networking Today',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Networks Affect Our Lives\nNetwork Components\nNetwork Representations and Topologies\nCommon Types of Networks\nInternet Connections\nReliable Networks\nNetwork Trends\nNetwork Security\nThe IT Professional',NULL,NULL,NULL,NULL),(33,'Basic Switch and End Device Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Cisco IOS Access\nIOS Navigation\nThe Command Structure\nBasic Device Configuration\nSave Configurations\nPorts and Addresses\nConfigure IP Addressing\nVerify Connectivity',NULL,NULL,NULL,NULL),(34,'Protocols and Models',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'The Rules\nProtocols\nProtocol Suites\nStandards Organizations\nReference Models\nData Encapsulation\nData Access',NULL,NULL,NULL,NULL),(35,'Physical Layer',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Purpose of the Physical Layer\nPhysical Layer Characteristics\nCopper Cabling\nUTP Cabling\nFiber-Optic Cabling\nWireless Media',NULL,NULL,NULL,NULL),(36,'Number Systems',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Binary Number System\nHexadecimal Number System',NULL,NULL,NULL,NULL),(37,'Data Link Layer',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Purpose of the Data Link Layer\nTopologies\nData Link Frame',NULL,NULL,NULL,NULL),(38,'Ethernet Switching',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Ethernet Frame\nEthernet MAC Address\nThe MAC Address Table\nSwitch Speeds and Forwarding Methods',NULL,NULL,NULL,NULL),(39,'Network Layer',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Network Layer Characteristics\nIPv4 Packet\nIPv6 Packet\nHow a Host Routes\nRouter Routing Tables',NULL,NULL,NULL,NULL),(40,'Address Resolution',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'MAC and IP\nARP\nNeighbor Discovery',NULL,NULL,NULL,NULL),(41,'Basic Router Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Configure Initial Router Settings\nConfigure Interfaces\nConfigure the Default Gateway',NULL,NULL,NULL,NULL),(42,'IPv4 Addressing',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'IPv4 Address Structure\nIPv4 Unicast, Broadcast, and Multicast\nTypes of IPv4 Addresses\nNetwork Segmentation\nSubnet an IPv4 Network\nSubnet a /16 and /8 Prefix\nSubnet to Meet Requirements\nVariable Length Subnet Masking (VLSM)\nStructured Design',NULL,NULL,NULL,NULL),(43,'IPv6 Addressing',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'IPv4 Issues\nIPv6 Addressing\nIPv6 Address Types\nGUA and LLA Static Configuration\nDynamic Addressing for IPv6 GUAs\nDynamic Addressing for IPv6 LLAs\nIPv6 Multicast Addresses\nSubnet an IPv6 Network',NULL,NULL,NULL,NULL),(44,'ICMP',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'ICMP Messages\nPing and Traceroute Testing',NULL,NULL,NULL,NULL),(45,'Transport Layer',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Transportation of Data\nTCP Overview\nUDP Overview\nPort Numbers\nTCP Communication Process\nReliability and Flow Control\nUDP Communication',NULL,NULL,NULL,NULL),(46,'Application Layer',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Application, Presentation, and Session\nPeer-to-Peer\nWeb and Email Protocols\nIP Addressing Services\nFile Sharing Services',NULL,NULL,NULL,NULL),(47,'Network Security Fundamentals',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Security Threats and Vulnerabilities\nNetwork Attacks\nNetwork Attack Mitigation\nDevice Security',NULL,NULL,NULL,NULL),(48,'Build a Small Network',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Devices in a Small Network\nSmall Network Applications and Protocols\nScale to Larger Networks\nVerify Connectivity\nHost and IOS Commands\nTroubleshooting Methodologies\nTroubleshooting Scenarios',NULL,NULL,NULL,NULL),(49,'Basic Device Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Configure a Switch with Initial Settings\nConfigure Switch Ports\nSecure Remote Access\nBasic Router Configuration\nVerify Directly Connected Networks',NULL,NULL,NULL,NULL),(50,'Switching Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Frame Forwarding\nSwitching Domains',NULL,NULL,NULL,NULL),(51,'VLANs',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Overview of VLANs\nVLANs in a Multi-Switched Environment\nVLAN Configuration\nVLAN Trunks\nDynamic Trunking Protocol (DTP)',NULL,NULL,NULL,NULL),(52,'Inter-VLAN Routing',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Inter-VLAN Routing Operation\nRouter-on-a-Stick Inter-VLAN Routing\nInter-VLAN Routing Using Layer 3 Switches\nTroubleshoot Inter-VLAN Routing',NULL,NULL,NULL,NULL),(53,'STP',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Purpose of STP\nSTP Operations\nEvolution of STP',NULL,NULL,NULL,NULL),(54,'EtherChannel',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'EtherChannel Operation\nConfigure EtherChannel\nVerify and Troubleshoot EtherChannel',NULL,NULL,NULL,NULL),(55,'DHCPv4',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'DHCPv4 Concepts\nConfigure DHCPv4 Server\nConfigure DHCPv4 Client',NULL,NULL,NULL,NULL),(56,'SLAAC and DHCPv6 Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'IPv6 Global Unicast Address Assignment\nSLAAC\nDHCPv6\nConfigure DHCPv6 Server',NULL,NULL,NULL,NULL),(57,'FHRP Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'First Hop Redundancy Protocol\nHSRP',NULL,NULL,NULL,NULL),(58,'LAN Security Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Endpoint Security\nAccess Control\nLayer 2 Security Threats\nMAC Address Table Attack\nLAN Attacks',NULL,NULL,NULL,NULL),(59,'Switch Security Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Implement Port Security\nMitigate VLAN Attacks\nMitigate DHCP Attacks\nMitigate ARP Attacks\nMitigate STP Attacks',NULL,NULL,NULL,NULL),(60,'WLAN Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Introduction to Wireless\nComponents of WLANs\nWLAN Operation\nCAPWAP Operation\nChannel Management\nWLAN Threats\nSecure WLANs',NULL,NULL,NULL,NULL),(61,'WLAN Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Remote Site WLAN Configuration\nConfigure a Basic WLC WLAN\nConfigure a WPA2 Enterprise WLAN on the WLC\nTroubleshoot WLAN Issues',NULL,NULL,NULL,NULL),(62,'Routing Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Path Determination\nPacket Forwarding\nBasic Router Configuration Review\nIP Routing Table\nStatic and Dynamic Routing',NULL,NULL,NULL,NULL),(63,'IP Static Routing',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Static Routes\nConfigure IP Static Routes\nConfigure IP Default Static Routes\nConfigure Floating Static Routes\nConfigure Static Host Routes',NULL,NULL,NULL,NULL),(64,'Troubleshoot Static and Default Routes',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Packet Processing with Static Routes\nTroubleshoot IPv4 Static and Default Route Configuration',NULL,NULL,NULL,NULL),(65,'Single-Area OSPFv2 Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'OSPF Features and Characteristics\nOSPF Packets\nOSPF Operation',NULL,NULL,NULL,NULL),(66,'Single-Area OSPFv2 Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'OSPF Router ID\nPoint-to-Point OSPF Networks\nMultiaccess OSPF Networks\nModify Single-Area OSPFv2\nDefault Route Propagation\nVerify Single-Area OSPFv2',NULL,NULL,NULL,NULL),(67,'Network Security Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Current State of Cybersecurity\nThreat Actors\nThreat Actor Tools\nMalware\nCommon Network Attacks\nIP Vulnerabilities and Threats\nTCP and UDP Vulnerabilities\nIP Services\nNetwork Security Best Practices\nCryptography',NULL,NULL,NULL,NULL),(68,'ACL Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Purpose of ACLs\nWildcard Masks in ACLs\nGuidelines for ACL Creation\nTypes of IPv4 ACLs',NULL,NULL,NULL,NULL),(69,'ACLs for IPv4 Configuration',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Configure Standard IPv4 ACLs\nModify IPv4 ACLs\nSecure VTY Ports with a Standard IPv4 ACL\nConfigure Extended IPv4 ACLs',NULL,NULL,NULL,NULL),(70,'NAT for IPv4',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'NAT Characteristics\nTypes of NAT\nNAT Advantages\nConfigure Static NAT\nConfigure Dynamic NAT\nConfigure PAT\nNAT64',NULL,NULL,NULL,NULL),(71,'WAN Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Purpose of WANs\nWAN Operations\nTraditional WAN Connectivity\nModern WAN Connectivity\nInternet-Based Connectivity',NULL,NULL,NULL,NULL),(72,'VPN and IPsec Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'VPN Technology\nTypes of VPNs\nIPsec',NULL,NULL,NULL,NULL),(73,'QoS Concepts',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Network Transmission Quality\nTraffic Characteristics\nQueuing Algorithms\nQoS Models\nQoS Implementation Techniques',NULL,NULL,NULL,NULL),(74,'Network Management',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Device Discovery with CDP\nDevice Discovery with LLDP\nNTP\nSNMP\nSyslog\nRouter and Switch File Maintenance\nIOS Image Management',NULL,NULL,NULL,NULL),(75,'Network Design',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Hierarchical Networks\nScalable Networks\nSwitch Hardware\nRouter Hardware',NULL,NULL,NULL,NULL),(76,'Network Troubleshooting',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Network Documentation\nTroubleshooting Process\nTroubleshooting Tools\nSymptoms and Causes of Network Problems\nTroubleshooting IP Connectivity',NULL,NULL,NULL,NULL),(77,'Network Virtualization',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Cloud Computing\nVirtualization\nVirtual Network Infrastructure\nSoftware-Defined Networking\nControllers',NULL,NULL,NULL,NULL),(78,'Network Automation',NULL,NULL,NULL,'2026-11-10 20:41:31','2026-11-11 14:33:39',2,'Automation Overview\nData Formats\nAPIs\nREST\nConfiguration Management\nIBN and Cisco DNA Center',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cost`
--

DROP TABLE IF EXISTS `cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cost` (
  `cost_id` int NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) NOT NULL,
  `description` varchar(600) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`cost_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `cost_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cost`
--

LOCK TABLES `cost` WRITE;
/*!40000 ALTER TABLE `cost` DISABLE KEYS */;
INSERT INTO `cost` VALUES (1,'80','Costo Curso','2025-01-23 19:42:10','2025-01-23 19:42:10',NULL),(2,'130','Costo Curso','2025-01-23 19:42:10','2025-01-23 19:42:10',NULL);
/*!40000 ALTER TABLE `cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `start_registration_date` datetime DEFAULT NULL,
  `end_registration_date` datetime DEFAULT NULL,
  `start_enrollment_date` datetime DEFAULT NULL,
  `end_enrollment_date` datetime DEFAULT NULL,
  `detail_id` int DEFAULT NULL,
  `template_course_id` int DEFAULT NULL,
  `class_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `created_by` (`created_by`),
  KEY `detail_id` (`detail_id`),
  KEY `fk_course_template` (`template_course_id`),
  CONSTRAINT `course_detail_id_foreign_idx` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `course_ibfk_2` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `fk_course_template` FOREIGN KEY (`template_course_id`) REFERENCES `course` (`course_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (2,'CCNA 1 v7: Introducción a las Redes (ITN)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-11-10 20:41:31',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL),(3,'CCNA 2 v7: Switching, Routing, and Wireless Essentials (SRWE)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-11-10 20:41:31',NULL,NULL,NULL,NULL,NULL,6,NULL,NULL),(4,'CCNA 3 v7: Enterprise Networking, Security, and Automation (ENSA)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-11-10 20:41:31',NULL,NULL,NULL,NULL,NULL,17,NULL,NULL);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_chapter`
--

DROP TABLE IF EXISTS `course_chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_chapter` (
  `course_chapter_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int DEFAULT NULL,
  `chapter_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  PRIMARY KEY (`course_chapter_id`),
  KEY `course_id` (`course_id`),
  KEY `chapter_id` (`chapter_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `course_chapter_ibfk_4` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `course_chapter_ibfk_5` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`),
  CONSTRAINT `course_chapter_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_chapter`
--

LOCK TABLES `course_chapter` WRITE;
/*!40000 ALTER TABLE `course_chapter` DISABLE KEYS */;
INSERT INTO `course_chapter` VALUES (180,2,32,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,1),(181,2,33,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,2),(182,2,34,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,3),(183,2,35,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,4),(184,2,36,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,5),(185,2,37,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,6),(186,2,38,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,7),(187,2,39,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,8),(188,2,40,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,9),(189,2,41,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,10),(190,2,42,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,11),(191,2,43,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,12),(192,2,44,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,13),(193,2,45,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,14),(194,2,46,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,15),(195,2,47,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,16),(196,2,48,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,17),(197,3,49,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,1),(198,3,50,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,2),(199,3,51,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,3),(200,3,52,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,4),(201,3,53,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,5),(202,3,54,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,6),(203,3,55,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,7),(204,3,56,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,8),(205,3,57,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,9),(206,3,58,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,10),(207,3,59,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,11),(208,3,60,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,12),(209,3,61,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,13),(210,3,62,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,14),(211,3,63,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,15),(212,3,64,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,16),(213,4,65,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,1),(214,4,66,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,2),(215,4,67,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,3),(216,4,68,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,4),(217,4,69,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,5),(218,4,70,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,6),(219,4,71,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,7),(220,4,72,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,8),(221,4,73,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,9),(222,4,74,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,10),(223,4,75,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,11),(224,4,76,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,12),(225,4,77,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,13),(226,4,78,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,14);
/*!40000 ALTER TABLE `course_chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_participant`
--

DROP TABLE IF EXISTS `course_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_participant` (
  `course_participant_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int DEFAULT NULL,
  `participant_id` int DEFAULT NULL,
  `total_payment` decimal(10,2) DEFAULT '0.00',
  `invoice_number` varchar(50) DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `validation_date` date DEFAULT NULL,
  `enrolled` tinyint(1) DEFAULT '1',
  `approval` tinyint(1) DEFAULT '0',
  `grade_final` decimal(5,2) DEFAULT NULL,
  `status_code` varchar(10) DEFAULT 'I',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`course_participant_id`),
  KEY `course_id` (`course_id`),
  KEY `participant_id` (`participant_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `course_participant_ibfk_4` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `course_participant_ibfk_5` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`),
  CONSTRAINT `course_participant_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_participant`
--

LOCK TABLES `course_participant` WRITE;
/*!40000 ALTER TABLE `course_participant` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail`
--

DROP TABLE IF EXISTS `detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail` (
  `detail_id` int NOT NULL AUTO_INCREMENT,
  `instructor_id` int DEFAULT NULL,
  `course_description` text NOT NULL,
  `total_hours` int DEFAULT NULL,
  `num_registered` int DEFAULT NULL,
  `num_enrolled` int DEFAULT NULL,
  `num_failed` int DEFAULT NULL,
  `detail_value_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `cost_per_hour` decimal(10,2) DEFAULT NULL,
  `instructor_hours` int DEFAULT NULL,
  `activities_hours` int DEFAULT NULL,
  `participant_requeriment` varchar(255) DEFAULT NULL,
  `course_name_en` varchar(255) DEFAULT NULL,
  `subject_area` varchar(255) DEFAULT NULL,
  `target_audience` varchar(255) DEFAULT NULL,
  `payment_methods` varchar(255) DEFAULT NULL,
  `objective` text,
  `specific_objectives` text,
  `justification` text,
  `methodology` text,
  `evaluation_criteria` text,
  `resources_materials` text,
  `bibliography` text,
  `academic_responsible` varchar(255) DEFAULT NULL,
  `academic_responsible_charge` varchar(255) DEFAULT NULL,
  `course_code` varchar(100) DEFAULT NULL,
  `prerequisites` text,
  PRIMARY KEY (`detail_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `detail_value_id` (`detail_value_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_2` FOREIGN KEY (`detail_value_id`) REFERENCES `detailvalues` (`detail_value_id`),
  CONSTRAINT `detail_ibfk_4` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_5` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_6` FOREIGN KEY (`detail_value_id`) REFERENCES `detailvalues` (`detail_value_id`),
  CONSTRAINT `detail_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail`
--

LOCK TABLES `detail` WRITE;
/*!40000 ALTER TABLE `detail` DISABLE KEYS */;
INSERT INTO `detail` VALUES (4,NULL,'Primer curso de la ruta CCNA v7 de Cisco Networking Academy. Desarrolla fundamentos de redes, modelos y protocolos, Ethernet, direccionamiento IPv4/IPv6, servicios, seguridad básica y configuración inicial de routers y switches. Estimación Cisco: 70 horas y 17 módulos.',70,0,0,0,NULL,'2026-10-29 14:30:14','2026-11-10 20:41:31',NULL,13.00,50,20,'Cisco señala que no hay prerrequisitos formales. Se recomienda manejo básico de computadores y navegación web.','CCNA v7: Introduction to Networks (ITN)','Redes y Telecomunicaciones','Estudiante Pregrado UTN, Estudiante Posgrado UTN, Egresado UTN, Graduado UTN, Particular','Efectivo, Tarjeta, Transferencia, Dos Pagos','Desarrollar conocimientos y destrezas fundamentales para explicar la comunicación en redes modernas y construir, configurar, verificar y diagnosticar una LAN pequeña con direccionamiento IPv4/IPv6 y prácticas básicas de seguridad.','1. Explicar componentes, topologías, modelos, protocolos y medios de red.\n2. Configurar parámetros iniciales y direccionamiento IP en switches, routers y hosts.\n3. Interpretar tramas Ethernet, direcciones MAC, paquetes IP y resolución de direcciones.\n4. Diseñar subredes IPv4/IPv6 y verificar conectividad extremo a extremo.\n5. Explicar transporte, servicios de aplicación y fundamentos de seguridad.\n6. Aplicar un método básico de solución de problemas en una red pequeña.','Proporciona la base técnica de la ruta CCNA para comprender, configurar y verificar redes LAN y conectividad IP.','Curso guiado por instructor con conceptos, ejercicios de direccionamiento, configuración Cisco IOS, simulación Cisco Packet Tracer o equipos disponibles, prácticas y comprobaciones de aprendizaje.','Actividades y autoevaluaciones por módulo; prácticas guiadas y de simulación; verificaciones de conectividad; evaluaciones de progreso y evaluación final. La ponderación y aprobación se fijan en cada edición conforme a reglas institucionales.','Computador con Internet; Cisco Networking Academy; Cisco Packet Tracer y/o routers, switches, cableado y equipos finales disponibles para laboratorio; guías del curso.','Cisco Networking Academy. CCNAv7: ITN v7, Scope and Sequence. Actualizado el 10 de diciembre de 2019. Cisco Press, Companion Guide CCNAv7.','MSc. Ludmila Starodub','Analista de sistemas – Coordinadora Academia CISCO','ITN v7','Cisco señala que no hay prerrequisitos formales. Se recomienda manejo básico de computadores y navegación web.'),(6,NULL,'Segundo curso de CCNA v7 enfocado en switching, operación de routers, WLAN y seguridad de LAN para redes de pequeñas y medianas empresas. Estimación Cisco: 70 horas y 16 módulos.',70,0,0,0,NULL,'2026-10-29 15:18:14','2026-11-10 20:41:31',NULL,NULL,NULL,NULL,'Completar CCNA v7: Introduction to Networks (ITN); manejo básico de computador e Internet.','CCNA v7: Switching, Routing, and Wireless Essentials (SRWE)','Redes, Conmutación, Enrutamiento y Redes Inalámbricas','Estudiante Pregrado UTN, Estudiante Posgrado UTN, Egresado UTN, Graduado UTN, Particular','Efectivo, Tarjeta, Transferencia, Dos Pagos','Configurar y solucionar problemas básicos de switching, routing y WLAN integrando VLAN, redundancia, servicios IPv4/IPv6, seguridad de LAN y rutas estáticas.','1. Configurar switches, VLAN, troncales y routing entre VLAN.\n2. Aplicar STP, EtherChannel y redundancia de gateway.\n3. Configurar DHCPv4, SLAAC y DHCPv6.\n4. Aplicar controles de seguridad LAN y endurecer switches.\n5. Configurar y proteger WLAN básica.\n6. Configurar rutas estáticas IPv4/IPv6 y diagnosticar rutas por defecto y conectividad.','Amplía los fundamentos de ITN hacia la operación de redes empresariales con segmentación, disponibilidad, acceso inalámbrico, seguridad y routing.','Curso guiado por instructor con configuración IOS, laboratorios físicos o simulados, Cisco Packet Tracer, análisis de LAN/WLAN y evaluaciones formativas y finales.','Actividades y autoevaluaciones por módulo; prácticas de VLAN, routing, seguridad y WLAN; verificaciones y troubleshooting; evaluaciones de progreso y final. La ponderación y aprobación se fijan en cada edición conforme a reglas institucionales.','Computador con Internet; Cisco Networking Academy; Cisco Packet Tracer y/o switches, routers, puntos de acceso/controlador WLAN y clientes disponibles para laboratorio.','Cisco Networking Academy. CCNAv7: SRWE v7, Scope and Sequence. Actualizado el 10 de diciembre de 2019. Cisco Press, Companion Guide CCNAv7.','MSc. Ludmila Starodub','Analista de sistemas – Coordinadora Academia CISCO','SRWE v7','Completar CCNA v7: Introduction to Networks (ITN) antes de iniciar SRWE; además, conocimientos básicos de lectura, manejo de computador y uso de Internet.'),(17,NULL,'Curso final de CCNA v7. Aborda OSPF de área única, seguridad empresarial, ACL, NAT, WAN, VPN/IPsec, QoS, gestión, diseño y troubleshooting de redes, virtualización y automatización. Estimación Cisco: 70 horas y 14 módulos.',70,0,0,0,NULL,'2026-11-10 20:41:31','2026-11-10 20:41:31',2,NULL,NULL,NULL,'Completar CCNA v7: Introduction to Networks (ITN) y Switching, Routing and Wireless Essentials (SRWE); manejo básico de computador e Internet.','CCNA v7: Enterprise Networking, Security, and Automation (ENSA)','Redes Empresariales, Seguridad y Automatización','Estudiante Pregrado UTN, Estudiante Posgrado UTN, Egresado UTN, Graduado UTN, Particular','Efectivo, Tarjeta, Transferencia, Dos Pagos','Configurar, proteger y diagnosticar redes empresariales de alcance básico aplicando OSPFv2, ACL y NAT, conceptos WAN/VPN, herramientas de gestión y fundamentos de virtualización y automatización.','1. Explicar y configurar OSPFv2 de área única.\n2. Configurar ACL IPv4 y NAT/PAT.\n3. Explicar soluciones WAN, VPN e IPsec.\n4. Describir QoS, gestión y diseño de redes empresariales.\n5. Aplicar metodología de troubleshooting.\n6. Explicar virtualización, SDN, controladores, APIs y automatización.','Completa la ruta CCNA integrando operación y seguridad empresarial, servicios de red, diagnóstico y tecnologías actuales de gestión y automatización.','Curso guiado por instructor con análisis de escenarios, laboratorios físicos o Cisco Packet Tracer, configuración y verificación de servicios y prácticas de troubleshooting.','Actividades y autoevaluaciones por módulo; laboratorios de OSPF, ACL y NAT; análisis de diseño y diagnóstico; evaluaciones de progreso y final. La ponderación y aprobación se fijan en cada edición conforme a reglas institucionales.','Computador con Internet; Cisco Networking Academy; Cisco Packet Tracer y/o routers, switches, servicios de red y herramientas de análisis disponibles; guías técnicas.','Cisco Networking Academy. CCNAv7: ENSA v7, Scope and Sequence. Actualizado el 10 de diciembre de 2019. Cisco Press, Companion Guide CCNAv7.','MSc. Ludmila Starodub','Analista de sistemas – Coordinadora Academia CISCO','ENSA v7','Completar CCNA v7: Introduction to Networks (ITN) y CCNA v7: Switching, Routing, and Wireless Essentials (SRWE) antes de iniciar ENSA; además, conocimientos básicos de lectura, manejo de computador y uso de Internet.');
/*!40000 ALTER TABLE `detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_modality`
--

DROP TABLE IF EXISTS `detail_modality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_modality` (
  `detail_modality_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `modality_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_modality_id`),
  KEY `detail_id` (`detail_id`),
  KEY `modality_id` (`modality_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_modality_ibfk_4` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detail_modality_ibfk_5` FOREIGN KEY (`modality_id`) REFERENCES `modality` (`modality_id`),
  CONSTRAINT `detail_modality_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_modality`
--

LOCK TABLES `detail_modality` WRITE;
/*!40000 ALTER TABLE `detail_modality` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_modality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_schedule`
--

DROP TABLE IF EXISTS `detail_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_schedule` (
  `detail_schedule_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `schedule_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_schedule_id`),
  KEY `detail_id` (`detail_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_schedule_ibfk_4` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detail_schedule_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`),
  CONSTRAINT `detail_schedule_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_schedule`
--

LOCK TABLES `detail_schedule` WRITE;
/*!40000 ALTER TABLE `detail_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detailcost`
--

DROP TABLE IF EXISTS `detailcost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detailcost` (
  `detail_cost_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `cost_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`detail_cost_id`),
  KEY `detail_id` (`detail_id`),
  KEY `cost_id` (`cost_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detailcost_ibfk_1` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detailcost_ibfk_2` FOREIGN KEY (`cost_id`) REFERENCES `cost` (`cost_id`),
  CONSTRAINT `detailcost_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detailcost`
--

LOCK TABLES `detailcost` WRITE;
/*!40000 ALTER TABLE `detailcost` DISABLE KEYS */;
INSERT INTO `detailcost` VALUES (5,4,1,NULL,'2026-10-29 14:30:14','2026-10-29 14:30:14'),(6,4,2,NULL,'2026-10-29 14:30:14','2026-10-29 14:30:14');
/*!40000 ALTER TABLE `detailcost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detailvalues`
--

DROP TABLE IF EXISTS `detailvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detailvalues` (
  `detail_value_id` int NOT NULL AUTO_INCREMENT,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `instructor_payment` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_value_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detailvalues_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detailvalues`
--

LOCK TABLES `detailvalues` WRITE;
/*!40000 ALTER TABLE `detailvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `detailvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_utn`
--

DROP TABLE IF EXISTS `info_utn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info_utn` (
  `info_utn_id` int NOT NULL AUTO_INCREMENT,
  `faculty` varchar(255) DEFAULT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `degree_level` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`info_utn_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `info_utn_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_utn`
--

LOCK TABLES `info_utn` WRITE;
/*!40000 ALTER TABLE `info_utn` DISABLE KEYS */;
INSERT INTO `info_utn` VALUES (1,'FICA','CITEL - Ingeniería en Telecomunicaciones','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(2,'FICA','CIELE - Ingeniería en Electricidad','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(3,'FICA','CISIC - Ingeniería en Software / Sistemas','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(4,'FICA','CIMET - Ingeniería Mecatrónica','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(5,'FICA','CII - Ingeniería Industrial','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(6,'FICA','CIT - Ingeniería Automotriz','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(7,'FECYT','Pedagogía de las Ciencias Experimentales','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(8,'FECYT','Diseño y Gestión de Marca','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(9,'FECYT','Psicología','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(10,'FACAE','Administración de Empresas','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(11,'FACAE','Contabilidad y Auditoría','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(12,'FACAE','Economía','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(13,'FACAE','Comercio Exterior','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(14,'FICAYA','Ingeniería Agropecuaria','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(15,'FICAYA','Ingeniería Ambiental','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(16,'FICAYA','Biotecnología','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(17,'FCCSS','Enfermería','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(18,'FCCSS','Fisioterapia','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(19,'FCCSS','Nutrición y Dietética','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(20,'POSGRADO','Maestría en Redes y Telecomunicaciones','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(21,'POSGRADO','Maestría en Tecnologías de la Información','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL);
/*!40000 ALTER TABLE `info_utn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor` (
  `instructor_id` int NOT NULL AUTO_INCREMENT,
  `identification_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ruc_number` varchar(15) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `banck_certificate_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`instructor_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `instructor_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor`
--

LOCK TABLES `instructor` WRITE;
/*!40000 ALTER TABLE `instructor` DISABLE KEYS */;
INSERT INTO `instructor` VALUES (1,'1001580396001','Cosme Ortega','0999440944','mc.ortega@utn.edu.ec',NULL,'2025-01-23 19:27:17','2025-01-23 19:27:17',NULL,'sin registro');
/*!40000 ALTER TABLE `instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor_certificate`
--

DROP TABLE IF EXISTS `instructor_certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_certificate` (
  `instructor_certificate_id` int NOT NULL AUTO_INCREMENT,
  `instructor_id` int DEFAULT NULL,
  `certificate_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`instructor_certificate_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `certificate_id` (`certificate_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `instructor_certificate_ibfk_4` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `instructor_certificate_ibfk_5` FOREIGN KEY (`certificate_id`) REFERENCES `certificate` (`certificate_id`),
  CONSTRAINT `instructor_certificate_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_certificate`
--

LOCK TABLES `instructor_certificate` WRITE;
/*!40000 ALTER TABLE `instructor_certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructor_certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modality`
--

DROP TABLE IF EXISTS `modality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modality` (
  `modality_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`modality_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `modality_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modality`
--

LOCK TABLES `modality` WRITE;
/*!40000 ALTER TABLE `modality` DISABLE KEYS */;
INSERT INTO `modality` VALUES (1,'Virtual','Modalidad Virtual','2024-10-05 17:36:51','2024-10-05 17:36:51',NULL),(2,'Presencial','Modalidad Presencial','2024-10-05 17:36:51','2024-10-05 17:36:51',NULL),(3,'Hibrida','Modalidad Virtual/Presencial','2024-10-05 17:36:51','2024-10-05 17:36:51',NULL);
/*!40000 ALTER TABLE `modality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant`
--

DROP TABLE IF EXISTS `participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant` (
  `participant_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cid` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `participant_type_id` int DEFAULT NULL,
  `degree` varchar(100) DEFAULT NULL,
  `degree_level` int DEFAULT NULL,
  `certificate_required` tinyint(1) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `enrolled` tinyint(1) DEFAULT NULL,
  `registered` tinyint(1) DEFAULT NULL,
  `approval` tinyint(1) DEFAULT NULL,
  `total_payment` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `participant_type_id` (`participant_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_ibfk_1` FOREIGN KEY (`participant_type_id`) REFERENCES `participant_type` (`participant_type_id`) ON DELETE SET NULL,
  CONSTRAINT `participant_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant`
--

LOCK TABLES `participant` WRITE;
/*!40000 ALTER TABLE `participant` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_info_utn`
--

DROP TABLE IF EXISTS `participant_info_utn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_info_utn` (
  `participant_id` int NOT NULL,
  `info_utn_id` int NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`info_utn_id`),
  KEY `info_utn_id` (`info_utn_id`),
  KEY `participant_info_utn_created_by_foreign_idx` (`created_by`),
  CONSTRAINT `participant_info_utn_created_by_foreign_idx` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `participant_info_utn_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_info_utn_ibfk_2` FOREIGN KEY (`info_utn_id`) REFERENCES `info_utn` (`info_utn_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_info_utn`
--

LOCK TABLES `participant_info_utn` WRITE;
/*!40000 ALTER TABLE `participant_info_utn` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant_info_utn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_payment`
--

DROP TABLE IF EXISTS `participant_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_payment` (
  `participant_payment_id` int NOT NULL AUTO_INCREMENT,
  `participant_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`participant_payment_id`),
  KEY `participant_id` (`participant_id`),
  KEY `payment_id` (`payment_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_payment_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_payment_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_payment_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_payment`
--

LOCK TABLES `participant_payment` WRITE;
/*!40000 ALTER TABLE `participant_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_type`
--

DROP TABLE IF EXISTS `participant_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_type` (
  `participant_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`participant_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_type_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_type`
--

LOCK TABLES `participant_type` WRITE;
/*!40000 ALTER TABLE `participant_type` DISABLE KEYS */;
INSERT INTO `participant_type` VALUES (1,'Estudiante Pregrado UTN','Activo','2025-01-20 15:36:59','2025-01-20 15:36:59',NULL),(2,'Egresado UTN','Activo','2025-01-20 15:37:11','2025-01-20 15:37:11',NULL),(3,'Estudiante Posgrado UTN','Activo','2025-01-20 15:37:26','2025-01-20 15:37:26',NULL),(4,'Particular','Activo','2025-01-20 15:37:50','2025-01-20 15:37:50',NULL),(5,'Docente UTN','Activo','2025-01-20 15:38:01','2025-01-20 15:38:01',NULL),(6,'Graduado UTN','Activo','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(7,'Administrativo UTN','Activo','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL);
/*!40000 ALTER TABLE `participant_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `payer_cid_ruc` varchar(20) DEFAULT NULL,
  `payer_name` varchar(255) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT '0.00',
  `iva` decimal(10,2) DEFAULT '0.00',
  `description` text,
  `amount` decimal(10,2) DEFAULT NULL,
  `project_code` varchar(50) DEFAULT '0607',
  `course_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`payment_type_id`) REFERENCES `payment_type` (`payment_type_id`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_type`
--

DROP TABLE IF EXISTS `payment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_type` (
  `payment_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`payment_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_type_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_type`
--

LOCK TABLES `payment_type` WRITE;
/*!40000 ALTER TABLE `payment_type` DISABLE KEYS */;
INSERT INTO `payment_type` VALUES (1,'Efectivo','2025-02-04 19:20:43','2025-02-04 19:20:43',NULL),(2,'Tarjeta','2025-02-04 19:20:52','2025-02-04 19:20:52',NULL),(3,'Transferencia','2025-02-04 19:20:59','2025-02-04 19:20:59',NULL),(4,'Dos Pagos','2025-02-04 19:21:04','2025-02-04 19:21:04',NULL);
/*!40000 ALTER TABLE `payment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `permission_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'Dashboard','Vista Dashboard','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(2,'Configuracion','Vista Configuracion','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(3,'Detalles','Vista Detalles','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(4,'Auditoria','Vista Auditoria','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(5,'Roles','Vista Roles','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(6,'Permisos','Vista Permisos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(7,'Pago','Vista Pago','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(8,'Tipo de Pago','Vista Tipo de Pago','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(9,'Convenios','Vista Convenios','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(10,'Activos','Vista Activos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(11,'Detalle de Valores','Vista Detalle de Valores','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(12,'Curso','Vista Curso','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(13,'Participante','Vista Participante','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(14,'Capítulos','Vista Capítulos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(15,'Usuarios','Vista Usuarios','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(16,'Detalles Test','Vista Dashboard','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',NULL),(17,'Gestionar cursos','Crear y administrar el catálogo, ediciones, planificación y reportes académicos de cursos.','Activo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(18,'Gestionar pagos','Consultar y administrar pagos, comprobantes y reportes de facturación.','Activo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(19,'Consultar dashboard','Consultar el tablero estadístico y el reporte anual sin acceder a funciones de edición.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(20,'Administrar usuarios y roles','Crear cuentas, asignar roles y administrar permisos.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(21,'Administrar datos maestros','Mantener tipos de participante, pagos, instructores y catálogos del sistema.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(22,'Consultar información','Consultar cursos, participantes, usuarios del sistema, facturación y dashboard, sin modificar registros.','Activo','2026-11-10 23:01:28','2026-11-10 23:01:28',NULL);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `role_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrador','Administración completa del sistema y sus datos maestros.','Activo','2024-10-05 17:36:51','2024-10-05 17:36:51',NULL),(4,'Visor','Consulta cursos, participantes, usuarios, facturación e informes sin modificar datos.','Activo','2026-11-11 01:18:28','2026-11-11 01:18:28',NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `role_permission_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int DEFAULT NULL,
  `permission_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`role_permission_id`),
  KEY `role_id` (`role_id`),
  KEY `permission_id` (`permission_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `role_permission_ibfk_4` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `role_permission_ibfk_5` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`permission_id`),
  CONSTRAINT `role_permission_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,1,17,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(2,1,18,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(28,1,22,'2026-11-10 23:01:28','2026-11-10 23:01:28',NULL),(30,4,22,'2026-11-11 01:18:28','2026-11-11 01:18:28',NULL);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `days` varchar(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`schedule_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,'2-3-4','19:30:00','21:30:00','2025-01-20 16:00:42','2025-01-20 16:00:42',NULL,NULL);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `users_role_id_foreign_idx` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Luis Flores','lhfloresc@utn.edu.ec','Ibarra','$2a$10$JTgBn0F9l.nwxMNP7VawkukI8SxGLXnSr28PjOQGoKjWt82SpTVSe','1','2026-04-24 11:38:59','2026-11-10 20:41:31',1),(9,'Ludmila Starodub','lvstarodub@utn.edu.ec',NULL,'$2a$10$JTgBn0F9l.nwxMNP7VawkukI8SxGLXnSr28PjOQGoKjWt82SpTVSe','1','2026-11-10 20:41:31','2026-11-10 20:41:31',1),(10,'Usuario Visor','visor@utn.edu.ec',NULL,'$2a$10$JTgBn0F9l.nwxMNP7VawkukI8SxGLXnSr28PjOQGoKjWt82SpTVSe','1','2026-11-10 20:41:31','2026-11-10 20:41:31',4);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'utn_cms'
--

--
-- Dumping routines for database 'utn_cms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-11  9:47:27
