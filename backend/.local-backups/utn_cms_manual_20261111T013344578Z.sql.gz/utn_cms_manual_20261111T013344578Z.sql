-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: utn_cms
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `utn_cms`
--

/*!40000 DROP DATABASE IF EXISTS `utn_cms`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `utn_cms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `utn_cms`;

--
-- Table structure for table `agreements`
--

DROP TABLE IF EXISTS `agreements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agreements` (
  `id_agreement` int NOT NULL AUTO_INCREMENT,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `sign_date` date DEFAULT NULL,
  `signatory` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id_agreement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agreements`
--

LOCK TABLES `agreements` WRITE;
/*!40000 ALTER TABLE `agreements` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id_asset` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id_asset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit`
--

DROP TABLE IF EXISTS `audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit` (
  `id_audit` int NOT NULL AUTO_INCREMENT,
  `audit_table` varchar(255) DEFAULT NULL,
  `audit_action` varchar(255) DEFAULT NULL,
  `audit_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_in_charge` int DEFAULT NULL,
  PRIMARY KEY (`id_audit`),
  KEY `user_in_charge` (`user_in_charge`),
  CONSTRAINT `audit_ibfk_1` FOREIGN KEY (`user_in_charge`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit`
--

LOCK TABLES `audit` WRITE;
/*!40000 ALTER TABLE `audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate` (
  `certificate_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `year_of_issue` int NOT NULL,
  `is_international` tinyint(1) NOT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `signatory_type` varchar(50) DEFAULT 'instructor',
  `signatory_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`certificate_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `certificate_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate`
--

LOCK TABLES `certificate` WRITE;
/*!40000 ALTER TABLE `certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter`
--

DROP TABLE IF EXISTS `chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter` (
  `chapter_id` int NOT NULL AUTO_INCREMENT,
  `chapter_name` varchar(255) NOT NULL,
  `hours` int DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `main_topics` text,
  `modality` varchar(100) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `session_start_time` time DEFAULT NULL,
  `session_end_time` time DEFAULT NULL,
  PRIMARY KEY (`chapter_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `chapter_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter`
--

LOCK TABLES `chapter` WRITE;
/*!40000 ALTER TABLE `chapter` DISABLE KEYS */;
INSERT INTO `chapter` VALUES (1,'Networking Today',1,'2022-02-15 20:03:00','2022-02-15 20:04:00','2025-01-16 20:05:11','2025-01-16 20:05:11',NULL,'Las redes afectan nuestras vidas\nComponentes de la red\nTopologías y representaciones de red\nTipos comunes de redes\nConexiones a Internet\nRedes confiables\nTendencias de red\nSeguridad de redes\nEl profesional de TI','Virtual','Lectura de módulo y autoevaluación VSC',NULL,NULL),(2,'Basic Switch and End Device Configuration',1,'2022-02-15 20:05:00','2022-02-15 20:06:00','2025-01-16 20:06:13','2025-01-16 20:06:13',NULL,'Acceso a Cisco IOS\nNavegación IOS\nLa estructura de commandos\nConfiguración básica de dispositivos\nGuardar las configuraciones\nPuertos y direcciones\nConfigurar direccionamiento IP\nVerificar la conectividad','Virtual','Práctica Packet Tracer 2.3.7 y 2.9.2',NULL,NULL),(3,'Protocols and Models',2,'2022-02-16 20:06:00','2022-02-16 20:06:00','2025-01-16 20:07:05','2025-01-16 20:07:05',NULL,'Las reglas\nProtocolos\nSuites de protocolos\nOrganizaciones estándares\nModelos de referencia\nEncapsulamiento de datos\nAcceso a los datos','Virtual','Laboratorio Wireshark y Packet Tracer 3.5.5',NULL,NULL),(4,'Physical Layer',2,'2022-02-17 20:07:00','2022-02-17 20:07:00','2025-01-16 20:07:58','2025-01-16 20:07:58',NULL,'Propósito de la capa física\nCaracterísticas de la capa física\nCableado de cobre\nCableado UTP\nCableado de fibra óptica\nMedios inalámbricos','Virtual','Identificación de cableado y conectores físicos',NULL,NULL),(5,'Laboratorio Capitulo 1 y 2',2,'2022-02-22 20:13:00','2022-02-22 20:13:00','2025-01-16 20:14:08','2025-01-16 20:14:08',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(6,'Laboratorios Capitulo 3',2,'2022-02-23 20:14:00','2022-02-23 20:15:00','2025-01-16 20:15:17','2025-01-16 20:15:17',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(7,'Laboratorios Capitulo 4',2,'2022-02-24 20:15:00','2022-02-24 20:15:00','2025-01-16 20:16:11','2025-01-16 20:16:11',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(8,'Number Systems',1,'2022-03-01 20:17:00','2022-03-01 20:17:00','2025-01-16 20:17:22','2025-01-16 20:17:22',NULL,'Sistema de numeración binaria\nSistema numérico hexadecimal','Virtual','Taller de conversión binaria y hexadecimal',NULL,NULL),(9,'Data Link Layer',1,'2022-03-01 20:17:00','2022-03-01 20:17:00','2025-01-16 20:18:08','2025-01-16 20:18:08',NULL,'Propósito de la capa de enlace de datos.\nTopologías.\nTrama de enlace de datos.','Virtual','Inspección de tramas Ethernet con analizador',NULL,NULL),(10,'Ethernet Switching',2,'2022-03-02 20:18:00','2022-03-02 20:18:00','2025-01-16 20:18:58','2025-01-16 20:18:58',NULL,'Trama de Ethernet\nDirección MAC de Ethernet\nLa tabla de direcciones MAC\nVelocidades y métodos de reenvío del switch','Virtual','Verificación de la tabla de direcciones MAC',NULL,NULL),(11,'Network Layer',1,'2022-03-03 20:19:00','2022-03-03 20:19:00','2025-01-16 20:19:39','2025-01-16 20:19:39',NULL,'Características de la capa de red\nPaquete IPv4\nPaquete IPv6\nCómo arma las rutas un host\nTablas de routing de router','Virtual','Examen de evaluación de Módulos 4 a 7',NULL,NULL),(12,'Addresss Resolution',1,'2022-03-03 20:20:00','2022-03-03 20:20:00','2025-01-16 20:20:31','2025-01-16 20:20:31',NULL,'MAC e IP\nARP\nDetección de vecinos','Virtual','Práctica Packet Tracer ARP e ICMP',NULL,NULL),(13,'Laboratorios Capitulos 5 y 6',2,'2022-03-09 01:20:00','2022-03-09 01:21:00','2025-01-16 20:21:15','2025-01-16 20:21:15',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(14,'Laboratorio Capitulo 7',2,'2022-03-09 20:21:00','2022-03-09 20:21:00','2025-01-16 20:22:05','2025-01-16 20:22:05',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(15,'Laboratorios Capitulo 8 y 9',2,'2022-03-10 20:22:00','2022-03-10 20:22:00','2025-01-16 20:22:43','2025-01-16 20:22:43',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(16,'Basic Router Configuration',1,'2022-03-15 19:18:00','2022-03-15 19:19:00','2025-01-17 19:19:27','2025-01-17 19:19:27',NULL,'Configuración de los parámetros iniciales del router\nConfiguración de interfaces\nConfiguración del gateway predeterminado','Virtual','Configuración de interfaces GigabitEthernet',NULL,NULL),(17,'IPv4 Addressing & subnets',1,'2022-03-15 19:20:00','2022-03-15 19:20:00','2025-01-17 19:20:36','2025-01-17 19:20:36',NULL,'Estructura de la dirección IPv4\nUnidifusión, difusión y multidifusión de IPv4\nTipos de direcciones IPv4\nSegmentación de la red\nDivisión de subredes de una red IPv4\nDivisión de subredes con prefijos /16 y /8\nDivisión en subredes para cumplir con requisites\nMáscara de subred de longitud variable\nDiseño estructurado','Virtual','Taller de subnetting VLSM y diseño de red',NULL,NULL),(18,'IPv6 Addressing',2,'2022-03-16 18:00:00','2022-03-15 18:00:00','2025-01-17 19:21:29','2025-01-17 19:21:29',NULL,'Problemas con IPv4\nAsignación de direcciones IPv6\nTipos de direcciones IPv6\nConfiguración estática de GUA y LLA\nDireccionamiento dinámico para GUA IPv6\nDireccionamiento dinámico para las LLAS IPv6\nDirecciones Multicast de IPv6\nDivisión de subredes de una red IPv6','Virtual','Configuración de direccionamiento estático y EUI-64',NULL,NULL),(19,'ICMP',2,'2022-03-17 18:00:00','2022-03-17 18:00:00','2025-01-17 19:22:05','2025-01-17 19:22:05',NULL,'Mensajes ICMP\nPruebas de ping y traceroute','Virtual','Pruebas de verificación y latencia ICMP',NULL,NULL),(20,'Laboratorios Capitulo 10 y 11',2,'2022-03-22 18:00:00','2022-03-22 18:00:00','2025-01-17 19:23:16','2025-01-17 19:23:16',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(21,'Laboratorios Capitulo 12',2,'2022-03-23 18:00:00','2022-03-23 18:00:00','2025-01-17 19:24:06','2025-01-17 19:24:06',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(22,'Laboratorios Capitulo 13',2,'2022-03-24 18:00:00','2022-03-24 18:00:00','2025-01-17 19:24:50','2025-01-17 19:24:50',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(23,'Transport Layer',2,'2022-03-29 18:00:00','2022-03-29 18:00:00','2025-01-17 19:28:17','2025-01-17 19:28:17',NULL,'Transporte de datos\nDescripción general de TCP\nDescripción general de UDP\nNúmeros de Puerto\nProceso de comunicación TCP\nConfiabilidad y control de flujo\nComunicación UDP','Virtual','Captura de flujo TCP de 3 vías con Wireshark',NULL,NULL),(24,'Application Layer',1,'2022-03-30 18:00:00','2022-03-30 18:00:00','2025-01-17 19:29:23','2025-01-17 19:29:23',NULL,'Aplicación, presentación y session\nPunto a punto\nProtocolos web y de correo electrónico\nServicios de direccionamiento IP\nServicios de intercambio de archivos','Virtual','Simulación de servicios DNS, HTTP y DHCP',NULL,NULL),(25,'Network Security Fundamentals',1,'2022-03-30 18:30:00','2022-03-30 18:30:00','2025-01-17 19:30:10','2025-01-17 19:30:10',NULL,'Vulnerabilidades y amenazas a la seguridad\nAtaques a la red\nMitigación de los ataques a la red\nSeguridad de los dispositivos','Virtual','Configuración de seguridad de puertos y SSH',NULL,NULL),(26,'Build a Small Network',2,'2022-03-31 18:00:00','2022-03-31 18:00:00','2025-01-17 19:30:54','2025-01-17 19:30:54',NULL,'Dispositivos de una red pequeña\nProtocolos y aplicaciones de redes pequeñas\nEscalamiento hacia redes más grandes\nVerificar la conectividad\nComandos de host y de IOS\nMetodologías para la solución de problemas\nEscenarios de resolución de problemas','Virtual','Proyecto integrador Packet Tracer de red pequeña',NULL,NULL),(27,'Laboratorios Capitulo 14',2,'2022-04-05 18:00:00','2022-04-05 18:00:00','2025-01-17 19:32:51','2025-01-17 19:32:51',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(28,'Laboratorios Capitulo 15 y 16',2,'2022-04-06 18:00:00','2022-04-06 18:00:00','2025-01-17 19:33:24','2025-01-17 19:33:24',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(29,'Laboratorios Capitulo 17',2,'2022-04-07 18:00:00','2022-04-07 18:00:00','2025-01-17 19:34:05','2025-01-17 19:34:05',NULL,'Prácticas guiadas de configuración de equipos físicos en laboratorio #4 de la FICA (routers Cisco ISR y switches Catalyst).','Presencial con instructor','Práctica de laboratorio presencial en equipos físicos FICA',NULL,NULL),(30,'Ejemplo',3,'2026-11-01 00:00:00','2026-11-25 00:00:00','2026-11-09 15:12:51','2026-11-09 15:12:51',NULL,'1\n2\n3\n4','Presencial con instructor','practica','14:12:00','13:12:00'),(31,'Ejemplo',3,'2026-11-19 00:00:00','2026-11-19 00:00:00','2026-11-09 15:20:57','2026-11-09 15:20:57',NULL,'1\n2\n3\n4\n5','Presencial con instructor','prueba de funcionamiento','03:12:00','13:12:00');
/*!40000 ALTER TABLE `chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cost`
--

DROP TABLE IF EXISTS `cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cost` (
  `cost_id` int NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) NOT NULL,
  `description` varchar(600) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`cost_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `cost_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cost`
--

LOCK TABLES `cost` WRITE;
/*!40000 ALTER TABLE `cost` DISABLE KEYS */;
INSERT INTO `cost` VALUES (1,'80','Costo Curso','2025-01-23 19:42:10','2025-01-23 19:42:10',1),(2,'130','Costo Curso','2025-01-23 19:42:10','2025-01-23 19:42:10',1);
/*!40000 ALTER TABLE `cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `course_name` varchar(255) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `start_registration_date` datetime DEFAULT NULL,
  `end_registration_date` datetime DEFAULT NULL,
  `start_enrollment_date` datetime DEFAULT NULL,
  `end_enrollment_date` datetime DEFAULT NULL,
  `detail_id` int DEFAULT NULL,
  `template_course_id` int DEFAULT NULL,
  `class_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `created_by` (`created_by`),
  KEY `detail_id` (`detail_id`),
  KEY `fk_course_template` (`template_course_id`),
  CONSTRAINT `course_detail_id_foreign_idx` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `course_ibfk_2` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `fk_course_template` FOREIGN KEY (`template_course_id`) REFERENCES `course` (`course_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'CCNAv7 Introduction to Networks (Español - 7.02)','2022-02-15 00:00:00','2022-04-10 00:00:00','Finalizado','2025-01-13 21:02:48','2025-01-13 21:02:48',NULL,'2022-01-20 00:00:00','2022-01-31 00:00:00','2022-02-01 18:00:00','2022-02-10 18:00:00',1,2,NULL),(2,'CCNA1 v7 Introduction to Networks (ITN)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,4,NULL,NULL),(3,'CCNA2 v7 Switching, Routing and Wireless Essentials (SRWE)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'CCNA3 v7 Enterprise Networking, Security and Automation (ENSA)',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'CCNP1-ENCOR Implementing and Operating Cisco Enterprise Network Core Technologies',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'CCNP2-ENARSI Implementing Cisco Enterprise Advanced Routing and Services',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'Programación en Python',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'JavaScript Essentials 1',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'DevNet Associate',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'IoT Security',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'CyberOps Associate',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'IT Essentials',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'Fundamentos de Linux',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,14,NULL,NULL),(14,'IoT Fundamentals: Connecting Things',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'IoT Fundamentals: Big Data & Analytics',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'IoT Fundamentals: Hackathon Playbook',NULL,NULL,'Plantilla','2026-05-21 19:02:43','2026-05-21 19:02:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'IoT Security - OCT-NOV2026','2026-10-01 05:00:00','2026-11-26 05:00:00','Iniciado','2026-10-27 16:18:07','2026-10-27 16:18:07',1,'2026-10-01 05:00:00','2026-10-01 05:00:00','2026-10-01 05:00:00','2026-10-01 05:00:00',NULL,10,NULL),(18,'Programación en Python - OCT-NOV2026','2026-10-01 00:00:00','2026-11-26 00:00:00','Planificado','2026-10-27 17:48:08','2026-10-27 17:48:08',1,NULL,NULL,NULL,NULL,NULL,7,NULL),(19,'Fundamentos de Linux - OCT-NOV2026','2026-10-13 00:00:00','2026-11-25 00:00:00','En inscripción','2026-10-27 18:57:34','2026-10-27 18:57:34',1,NULL,NULL,NULL,NULL,NULL,13,NULL),(20,'CCNA2 v7 Switching, Routing and Wireless Essentials (SRWE) - OCT-NOV2026','2026-10-13 00:00:00','2026-11-25 00:00:00','Planificado','2026-10-27 19:47:39','2026-10-27 19:47:39',1,NULL,NULL,NULL,NULL,NULL,3,NULL),(22,'DevNet Associate - OCT-NOV2026','2026-10-08 00:00:00','2026-10-31 00:00:00','Planificado','2026-10-29 14:24:17','2026-10-29 14:24:17',1,NULL,NULL,NULL,NULL,NULL,9,NULL),(23,'CCNA1 v7 Introduction to Networks (ITN) - OCT-NOV2026','2026-10-07 00:00:00','2026-10-30 00:00:00','Planificado','2026-10-29 14:27:02','2026-10-29 14:27:02',1,NULL,NULL,NULL,NULL,3,2,NULL),(24,'UTN_JAVASCRI_OCT-NOV2026','2026-10-15 00:00:00','2026-10-31 00:00:00','Planificado','2026-10-29 15:06:50','2026-10-29 15:06:50',1,'2026-10-01 00:00:00','2026-10-30 00:00:00',NULL,NULL,5,8,NULL),(25,'UTN_CCNA2_OCT-NOV2026','2026-10-07 00:00:00','2026-10-31 00:00:00','En ejecución','2026-10-29 15:18:14','2026-10-29 15:18:14',1,'2026-10-16 00:00:00','2026-10-18 00:00:00',NULL,NULL,6,3,NULL),(26,'UTN_CCNA1_OCT-NOV2026','2026-10-01 00:00:00','2026-11-19 00:00:00','Planificado','2026-10-29 19:37:44','2026-10-29 19:37:44',1,'2026-10-01 00:00:00','2026-10-09 00:00:00',NULL,NULL,7,2,NULL),(27,'UTN_IT_ESSEN_OCT-NOV2026','2026-11-01 00:00:00','2026-11-07 00:00:00','Planificado','2026-11-05 17:17:36','2026-11-05 17:17:36',1,'2026-11-12 00:00:00','2026-11-30 00:00:00',NULL,NULL,8,12,NULL),(30,'UTN_IT_ESSEN_OCT-NOV2026','2026-11-01 00:00:00','2026-11-07 00:00:00','En inscripción','2026-11-09 15:17:44','2026-11-09 15:17:44',1,'2026-11-12 00:00:00','2026-11-30 00:00:00',NULL,NULL,11,12,'UTN_IT_ESSEN_OCT-NOV2026'),(31,'UTN_IOT_FUND_OCT-NOV2026','2026-11-01 00:00:00','2026-11-07 00:00:00','Planificado','2026-11-09 15:18:35','2026-11-09 15:18:35',1,'2026-11-12 00:00:00','2026-11-30 00:00:00',NULL,NULL,12,16,'UTN_IOT_FUND_OCT-NOV2026'),(32,'UTN_IOT_FUND_OCT-NOV2026','2026-11-13 00:00:00','2026-11-17 00:00:00','Planificado','2026-11-09 15:22:26','2026-11-09 15:22:26',1,'2026-11-27 00:00:00','2026-11-28 00:00:00',NULL,NULL,13,16,'UTN_IOT_FUND_OCT-NOV2026'),(33,'UTN_FUNDAMEN_OCT-NOV2026','2026-11-05 00:00:00','2026-11-24 00:00:00','Planificado','2026-11-09 15:26:03','2026-11-09 15:26:03',1,'2026-11-25 00:00:00','2026-11-30 00:00:00',NULL,NULL,15,13,'UTN_FUNDAMEN_OCT-NOV2026');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_chapter`
--

DROP TABLE IF EXISTS `course_chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_chapter` (
  `course_chapter_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int DEFAULT NULL,
  `chapter_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  PRIMARY KEY (`course_chapter_id`),
  KEY `course_id` (`course_id`),
  KEY `chapter_id` (`chapter_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `course_chapter_ibfk_4` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `course_chapter_ibfk_5` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`chapter_id`),
  CONSTRAINT `course_chapter_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_chapter`
--

LOCK TABLES `course_chapter` WRITE;
/*!40000 ALTER TABLE `course_chapter` DISABLE KEYS */;
INSERT INTO `course_chapter` VALUES (1,1,1,'2025-01-16 20:05:11','2025-01-16 20:05:11',NULL,1),(2,1,2,'2025-01-16 20:06:13','2025-01-16 20:06:13',NULL,2),(3,1,3,'2025-01-16 20:07:05','2025-01-16 20:07:05',NULL,3),(4,1,4,'2025-01-16 20:07:58','2025-01-16 20:07:58',NULL,4),(5,1,5,'2025-01-16 20:14:08','2025-01-16 20:14:08',NULL,5),(6,1,6,'2025-01-16 20:15:17','2025-01-16 20:15:17',NULL,6),(7,1,7,'2025-01-16 20:16:11','2025-01-16 20:16:11',NULL,7),(8,1,8,'2025-01-16 20:17:22','2025-01-16 20:17:22',NULL,8),(9,1,9,'2025-01-16 20:18:08','2025-01-16 20:18:08',NULL,9),(10,1,10,'2025-01-16 20:18:58','2025-01-16 20:18:58',NULL,10),(11,1,11,'2025-01-16 20:19:39','2025-01-16 20:19:39',NULL,11),(12,1,12,'2025-01-16 20:20:31','2025-01-16 20:20:31',NULL,12),(13,1,13,'2025-01-16 20:21:15','2025-01-16 20:21:15',NULL,13),(14,1,14,'2025-01-16 20:22:05','2025-01-16 20:22:05',NULL,14),(15,1,15,'2025-01-16 20:22:44','2025-01-16 20:22:44',NULL,15),(16,1,16,'2025-01-17 19:19:27','2025-01-17 19:19:27',NULL,16),(17,1,17,'2025-01-17 19:20:37','2025-01-17 19:20:37',NULL,17),(18,1,18,'2025-01-17 19:21:29','2025-01-17 19:21:29',NULL,18),(19,1,19,'2025-01-17 19:22:05','2025-01-17 19:22:05',NULL,19),(20,1,20,'2025-01-17 19:23:16','2025-01-17 19:23:16',NULL,20),(21,1,21,'2025-01-17 19:24:06','2025-01-17 19:24:06',NULL,21),(22,1,22,'2025-01-17 19:24:50','2025-01-17 19:24:50',NULL,22),(23,1,23,'2025-01-17 19:28:17','2025-01-17 19:28:17',NULL,23),(24,1,24,'2025-01-17 19:29:23','2025-01-17 19:29:23',NULL,24),(25,1,25,'2025-01-17 19:30:10','2025-01-17 19:30:10',NULL,25),(26,1,26,'2025-01-17 19:30:54','2025-01-17 19:30:54',NULL,26),(27,1,27,'2025-01-17 19:32:51','2025-01-17 19:32:51',NULL,27),(28,1,28,'2025-01-17 19:33:24','2025-01-17 19:33:24',NULL,28),(29,1,29,'2025-01-17 19:34:05','2025-01-17 19:34:05',NULL,29),(30,2,1,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,30),(31,2,2,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,31),(32,2,3,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,32),(33,2,4,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,33),(34,2,5,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,34),(35,2,6,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,35),(36,2,7,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,36),(37,2,8,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,37),(38,2,9,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,38),(39,2,10,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,39),(40,2,11,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,40),(41,2,12,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,41),(42,2,13,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,42),(43,2,14,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,43),(44,2,15,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,44),(45,2,16,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,45),(46,2,17,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,46),(47,2,18,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,47),(48,2,19,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,48),(49,2,20,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,49),(50,2,21,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,50),(51,2,22,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,51),(52,2,23,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,52),(53,2,24,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,53),(54,2,25,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,54),(55,2,26,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,55),(56,2,27,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,56),(57,2,28,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,57),(58,2,29,'2026-10-29 14:08:42','2026-10-29 14:08:42',NULL,58),(90,23,1,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,90),(91,23,2,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,91),(92,23,3,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,92),(93,23,4,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,93),(94,23,5,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,94),(95,23,6,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,95),(96,23,7,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,96),(97,23,8,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,97),(98,23,9,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,98),(99,23,10,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,99),(100,23,11,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,100),(101,23,12,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,101),(102,23,13,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,102),(103,23,14,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,103),(104,23,15,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,104),(105,23,16,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,105),(106,23,17,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,106),(107,23,18,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,107),(108,23,19,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,108),(109,23,20,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,109),(110,23,21,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,110),(111,23,22,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,111),(112,23,23,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,112),(113,23,24,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,113),(114,23,25,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,114),(115,23,26,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,115),(116,23,27,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,116),(117,23,28,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,117),(118,23,29,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,118),(148,26,1,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,148),(149,26,2,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,149),(150,26,3,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,150),(151,26,4,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,151),(152,26,5,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,152),(153,26,6,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,153),(154,26,7,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,154),(155,26,8,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,155),(156,26,9,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,156),(157,26,10,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,157),(158,26,11,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,158),(159,26,12,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,159),(160,26,13,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,160),(161,26,14,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,161),(162,26,15,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,162),(163,26,16,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,163),(164,26,17,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,164),(165,26,18,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,165),(166,26,19,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,166),(167,26,20,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,167),(168,26,21,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,168),(169,26,22,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,169),(170,26,23,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,170),(171,26,24,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,171),(172,26,25,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,172),(173,26,26,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,173),(174,26,27,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,174),(175,26,28,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,175),(176,26,29,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,176),(177,16,30,'2026-11-09 15:12:51','2026-11-09 15:12:51',NULL,1),(178,31,31,'2026-11-09 15:18:35','2026-11-09 15:18:35',NULL,1),(179,32,30,'2026-11-09 15:22:26','2026-11-09 15:22:26',NULL,1);
/*!40000 ALTER TABLE `course_chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_participant`
--

DROP TABLE IF EXISTS `course_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_participant` (
  `course_participant_id` int NOT NULL AUTO_INCREMENT,
  `course_id` int DEFAULT NULL,
  `participant_id` int DEFAULT NULL,
  `total_payment` decimal(10,2) DEFAULT '0.00',
  `invoice_number` varchar(50) DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `validation_date` date DEFAULT NULL,
  `enrolled` tinyint(1) DEFAULT '1',
  `approval` tinyint(1) DEFAULT '0',
  `grade_final` decimal(5,2) DEFAULT NULL,
  `status_code` varchar(10) DEFAULT 'I',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`course_participant_id`),
  KEY `course_id` (`course_id`),
  KEY `participant_id` (`participant_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `course_participant_ibfk_4` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `course_participant_ibfk_5` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`),
  CONSTRAINT `course_participant_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_participant`
--

LOCK TABLES `course_participant` WRITE;
/*!40000 ALTER TABLE `course_participant` DISABLE KEYS */;
INSERT INTO `course_participant` VALUES (1,1,3,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:19:37','2025-01-23 20:19:37',NULL),(2,1,2,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:20:26','2025-01-23 20:20:26',NULL),(3,1,1,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:20:43','2025-01-23 20:20:43',NULL),(4,1,4,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:41','2025-01-23 20:25:41',NULL),(5,1,5,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:42','2025-01-23 20:25:42',NULL),(6,1,6,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:42','2025-01-23 20:25:42',NULL),(8,1,8,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:43','2025-01-23 20:25:43',NULL),(9,1,9,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:43','2025-01-23 20:25:43',NULL),(10,1,10,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-01-23 20:25:43','2025-01-23 20:25:43',NULL),(11,1,11,0.00,NULL,NULL,NULL,0,0,50.00,'F','2025-02-11 17:23:26','2025-02-11 17:23:26',NULL),(12,1,12,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:26','2025-02-11 17:23:26',NULL),(13,1,13,0.00,NULL,NULL,NULL,0,0,50.00,'F','2025-02-11 17:23:27','2025-02-11 17:23:27',NULL),(14,1,14,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:27','2025-02-11 17:23:27',NULL),(15,1,15,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:27','2025-02-11 17:23:27',NULL),(16,1,16,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:27','2025-02-11 17:23:27',NULL),(17,1,17,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:28','2025-02-11 17:23:28',NULL),(18,1,18,0.00,NULL,NULL,NULL,0,0,50.00,'F','2025-02-11 17:23:28','2025-02-11 17:23:28',NULL),(19,1,19,0.00,NULL,NULL,NULL,0,1,85.00,'P','2025-02-11 17:23:28','2025-02-11 17:23:28',NULL),(20,24,7,0.00,NULL,NULL,NULL,0,1,70.00,'P','2026-10-29 16:14:48','2026-10-29 16:14:48',NULL),(21,24,19,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 16:43:28','2026-10-29 16:43:28',NULL),(22,24,20,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(23,24,21,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(24,24,22,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(25,24,23,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(26,24,24,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(27,24,25,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(28,24,26,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(29,24,27,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(30,24,28,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(31,24,29,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(32,24,30,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(33,24,31,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(34,24,32,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(35,24,33,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(36,24,34,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:04','2026-10-29 19:09:04',NULL),(37,24,35,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:05','2026-10-29 19:09:05',NULL),(38,24,36,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:05','2026-10-29 19:09:05',NULL),(39,24,37,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:09:05','2026-10-29 19:09:05',NULL),(40,26,1,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:44:14','2026-10-29 19:44:14',NULL),(41,26,20,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(42,26,21,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(43,26,22,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(44,26,23,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(45,26,24,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(46,26,25,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(47,26,26,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(48,26,27,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(49,26,28,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(50,26,29,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(51,26,30,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(52,26,31,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(53,26,32,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(54,26,33,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(55,26,34,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(56,26,35,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(57,26,36,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(58,26,37,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-10-29 19:46:23','2026-10-29 19:46:23',NULL),(59,27,13,69.00,'100100100',25,'2026-11-05',1,0,NULL,'I','2026-11-05 17:17:52','2026-11-05 17:17:52',NULL),(60,27,20,69.00,'2000200202',26,'2026-11-05',1,0,NULL,'I','2026-11-05 17:41:49','2026-11-05 17:41:49',NULL),(61,27,21,80.00,'115050505',27,'2026-11-05',1,0,NULL,'I','2026-11-05 17:41:49','2026-11-05 17:41:49',NULL),(62,27,22,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:49','2026-11-05 17:41:49',NULL),(63,27,23,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:49','2026-11-05 17:41:49',NULL),(64,27,24,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(65,27,25,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(66,27,26,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(67,27,27,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(68,27,28,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(69,27,29,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(70,27,30,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(71,27,31,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(72,27,32,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(73,27,33,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(74,27,34,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(75,27,35,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(76,27,36,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL),(77,27,37,0.00,NULL,NULL,NULL,0,0,NULL,'I','2026-11-05 17:41:50','2026-11-05 17:41:50',NULL);
/*!40000 ALTER TABLE `course_participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail`
--

DROP TABLE IF EXISTS `detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail` (
  `detail_id` int NOT NULL AUTO_INCREMENT,
  `instructor_id` int DEFAULT NULL,
  `course_description` text NOT NULL,
  `total_hours` int DEFAULT NULL,
  `num_registered` int DEFAULT NULL,
  `num_enrolled` int DEFAULT NULL,
  `num_failed` int DEFAULT NULL,
  `detail_value_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `cost_per_hour` decimal(10,2) DEFAULT NULL,
  `instructor_hours` int DEFAULT NULL,
  `activities_hours` int DEFAULT NULL,
  `participant_requeriment` varchar(255) DEFAULT NULL,
  `course_name_en` varchar(255) DEFAULT NULL,
  `subject_area` varchar(255) DEFAULT NULL,
  `target_audience` varchar(255) DEFAULT NULL,
  `payment_methods` varchar(255) DEFAULT NULL,
  `objective` text,
  `specific_objectives` text,
  `justification` text,
  `methodology` text,
  `evaluation_criteria` text,
  `resources_materials` text,
  `bibliography` text,
  `academic_responsible` varchar(255) DEFAULT NULL,
  `academic_responsible_charge` varchar(255) DEFAULT NULL,
  `course_code` varchar(100) DEFAULT NULL,
  `prerequisites` text,
  PRIMARY KEY (`detail_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `detail_value_id` (`detail_value_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_2` FOREIGN KEY (`detail_value_id`) REFERENCES `detailvalues` (`detail_value_id`),
  CONSTRAINT `detail_ibfk_4` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_5` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `detail_ibfk_6` FOREIGN KEY (`detail_value_id`) REFERENCES `detailvalues` (`detail_value_id`),
  CONSTRAINT `detail_ibfk_7` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail`
--

LOCK TABLES `detail` WRITE;
/*!40000 ALTER TABLE `detail` DISABLE KEYS */;
INSERT INTO `detail` VALUES (1,1,'Descipciòn del curso CCNAv7 Introducciòn a las Redes (Español - 7.02)',70,18,0,3,1,'2025-01-23 19:42:10','2025-01-23 19:42:10',NULL,13.00,48,22,'ninguno',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,2,'Descipciòn del curso CCNAv7 Introducciòn a las Redes (Español - 7.02)',70,0,0,0,NULL,'2026-10-29 14:27:02','2026-10-29 14:27:02',NULL,13.00,48,22,'ninguno',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,NULL,'Curso oficial CISCO CCNA1 v7: Introducción a las Redes (ITN)',70,0,0,0,NULL,'2026-10-29 14:30:14','2026-10-29 14:30:14',NULL,13.00,50,20,'Conocimientos básicos de computación y navegación web','CCNA1v7 \"Introduction to Networks (ITN)\"','Redes y Telecomunicaciones','Estudiantes, profesionales y público general','Contado / Dos pagos','Presentar los conceptos y tecnologías básicos de redes, para que el estudiante sea capaz de construir redes LAN simples, realizar configuraciones básicas para routers y switches e implementar esquemas de direccionamiento IP.','','El curso responde a la necesidad de capacitar talento humano en administración de redes de datos bajo estándares internacionales.','Clases magistrales y virtuales con instructor, talleres prácticos y laboratorios síncronos.','','Computadoras, proyector, switches Catalyst, routers Cisco, software Packet Tracer.','Material oficial Cisco Networking Academy (netacad.com)','MSc. Ludmila Starodub','Analista de sistemas – Coordinadora Academia CISCO','',''),(5,2,'Curso oficial CISCO: JavaScript Essentials 1',70,20,0,0,NULL,'2026-10-29 15:12:23','2026-10-29 15:12:23',NULL,100.00,50,20,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,1,'Curso oficial CISCO: CCNA2 v7 Switching, Routing and Wireless Essentials (SRWE)',70,0,0,0,NULL,'2026-10-29 15:18:14','2026-10-29 15:18:14',NULL,50.00,50,20,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,1,'Curso oficial CISCO CCNA1 v7: Introducción a las Redes (ITN)',70,19,0,0,NULL,'2026-10-29 19:37:44','2026-10-29 19:37:44',NULL,15.00,50,20,'Conocimientos básicos de computación y navegación web',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,1,'Curso oficial CISCO: IT Essentials',70,19,3,0,NULL,'2026-11-05 17:17:36','2026-11-05 17:17:36',NULL,13.00,50,20,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,1,'',NULL,0,0,0,NULL,'2026-11-09 15:17:44','2026-11-09 15:17:44',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,1,'',NULL,0,0,0,NULL,'2026-11-09 15:18:35','2026-11-09 15:18:35',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,2,'',NULL,0,0,0,NULL,'2026-11-09 15:22:26','2026-11-09 15:22:26',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,NULL,'',NULL,NULL,NULL,NULL,NULL,'2026-11-09 15:24:34','2026-11-09 15:24:34',NULL,NULL,NULL,NULL,'','','Prueba de funcionamiento','','','','','','','','','','','','',''),(15,1,'',NULL,0,0,0,NULL,'2026-11-09 15:26:03','2026-11-09 15:26:03',NULL,NULL,NULL,NULL,'','','Prueba de funcionamiento','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_modality`
--

DROP TABLE IF EXISTS `detail_modality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_modality` (
  `detail_modality_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `modality_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_modality_id`),
  KEY `detail_id` (`detail_id`),
  KEY `modality_id` (`modality_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_modality_ibfk_4` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detail_modality_ibfk_5` FOREIGN KEY (`modality_id`) REFERENCES `modality` (`modality_id`),
  CONSTRAINT `detail_modality_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_modality`
--

LOCK TABLES `detail_modality` WRITE;
/*!40000 ALTER TABLE `detail_modality` DISABLE KEYS */;
INSERT INTO `detail_modality` VALUES (3,4,3,'2026-10-29 14:30:14','2026-10-29 14:30:14',NULL),(10,1,1,'2026-10-29 15:16:46','2026-10-29 15:16:46',NULL),(11,5,1,'2026-10-29 15:17:02','2026-10-29 15:17:02',NULL),(13,6,1,'2026-10-29 15:18:33','2026-10-29 15:18:33',NULL),(14,3,2,'2026-10-29 15:31:38','2026-10-29 15:31:38',NULL),(16,7,3,'2026-10-29 19:39:00','2026-10-29 19:39:00',NULL),(17,8,1,'2026-11-05 17:17:36','2026-11-05 17:17:36',NULL),(18,11,2,'2026-11-09 15:17:44','2026-11-09 15:17:44',NULL),(19,12,2,'2026-11-09 15:18:35','2026-11-09 15:18:35',NULL),(20,13,2,'2026-11-09 15:22:26','2026-11-09 15:22:26',NULL),(21,15,2,'2026-11-09 15:26:03','2026-11-09 15:26:03',NULL);
/*!40000 ALTER TABLE `detail_modality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_schedule`
--

DROP TABLE IF EXISTS `detail_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_schedule` (
  `detail_schedule_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `schedule_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_schedule_id`),
  KEY `detail_id` (`detail_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detail_schedule_ibfk_4` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detail_schedule_ibfk_5` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`),
  CONSTRAINT `detail_schedule_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_schedule`
--

LOCK TABLES `detail_schedule` WRITE;
/*!40000 ALTER TABLE `detail_schedule` DISABLE KEYS */;
INSERT INTO `detail_schedule` VALUES (1,1,1,'2025-01-20 16:00:42','2025-01-20 16:00:42',1);
/*!40000 ALTER TABLE `detail_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detailcost`
--

DROP TABLE IF EXISTS `detailcost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detailcost` (
  `detail_cost_id` int NOT NULL AUTO_INCREMENT,
  `detail_id` int DEFAULT NULL,
  `cost_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`detail_cost_id`),
  KEY `detail_id` (`detail_id`),
  KEY `cost_id` (`cost_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detailcost_ibfk_1` FOREIGN KEY (`detail_id`) REFERENCES `detail` (`detail_id`),
  CONSTRAINT `detailcost_ibfk_2` FOREIGN KEY (`cost_id`) REFERENCES `cost` (`cost_id`),
  CONSTRAINT `detailcost_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detailcost`
--

LOCK TABLES `detailcost` WRITE;
/*!40000 ALTER TABLE `detailcost` DISABLE KEYS */;
INSERT INTO `detailcost` VALUES (1,1,1,1,'2025-01-23 19:42:10','2025-01-23 19:42:10'),(2,1,2,1,'2025-01-23 19:42:10','2025-01-23 19:42:10'),(3,3,1,NULL,'2026-10-29 14:27:02','2026-10-29 14:27:02'),(4,3,2,NULL,'2026-10-29 14:27:02','2026-10-29 14:27:02'),(5,4,1,NULL,'2026-10-29 14:30:14','2026-10-29 14:30:14'),(6,4,2,NULL,'2026-10-29 14:30:14','2026-10-29 14:30:14'),(7,7,1,NULL,'2026-10-29 19:37:44','2026-10-29 19:37:44'),(8,7,2,NULL,'2026-10-29 19:37:44','2026-10-29 19:37:44');
/*!40000 ALTER TABLE `detailcost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detailvalues`
--

DROP TABLE IF EXISTS `detailvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detailvalues` (
  `detail_value_id` int NOT NULL AUTO_INCREMENT,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `instructor_payment` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`detail_value_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `detailvalues_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detailvalues`
--

LOCK TABLES `detailvalues` WRITE;
/*!40000 ALTER TABLE `detailvalues` DISABLE KEYS */;
INSERT INTO `detailvalues` VALUES (1,2150.00,624.00,NULL,NULL,NULL);
/*!40000 ALTER TABLE `detailvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_utn`
--

DROP TABLE IF EXISTS `info_utn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info_utn` (
  `info_utn_id` int NOT NULL AUTO_INCREMENT,
  `faculty` varchar(255) DEFAULT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `degree_level` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`info_utn_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `info_utn_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_utn`
--

LOCK TABLES `info_utn` WRITE;
/*!40000 ALTER TABLE `info_utn` DISABLE KEYS */;
INSERT INTO `info_utn` VALUES (1,'FICA','CITEL - Ingeniería en Telecomunicaciones','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(2,'FICA','CIELE - Ingeniería en Electricidad','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(3,'FICA','CISIC - Ingeniería en Software / Sistemas','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(4,'FICA','CIMET - Ingeniería Mecatrónica','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(5,'FICA','CII - Ingeniería Industrial','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(6,'FICA','CIT - Ingeniería Automotriz','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(7,'FECYT','Pedagogía de las Ciencias Experimentales','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(8,'FECYT','Diseño y Gestión de Marca','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(9,'FECYT','Psicología','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(10,'FACAE','Administración de Empresas','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(11,'FACAE','Contabilidad y Auditoría','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(12,'FACAE','Economía','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(13,'FACAE','Comercio Exterior','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(14,'FICAYA','Ingeniería Agropecuaria','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(15,'FICAYA','Ingeniería Ambiental','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(16,'FICAYA','Biotecnología','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(17,'FCCSS','Enfermería','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(18,'FCCSS','Fisioterapia','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(19,'FCCSS','Nutrición y Dietética','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(20,'POSGRADO','Maestría en Redes y Telecomunicaciones','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(21,'POSGRADO','Maestría en Tecnologías de la Información','Pregrado/Posgrado','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(22,'FICA','CITEL','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(23,'FICA','CIELE','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(24,'FICA','Software','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(25,'FICA','Sistemas','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(26,'FICA','Mecatrónica','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(27,'FECYT','Ingeniería Civil','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(28,'FECYT','Ingeniería Ambiental','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(29,'FICAYA','Agronomía','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(30,'FACAE','Química','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(31,'FCCSS','Obstetricia','Pregrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(32,'Posgrado','Maestría en Ingeniería','Posgrado','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL);
/*!40000 ALTER TABLE `info_utn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor` (
  `instructor_id` int NOT NULL AUTO_INCREMENT,
  `identification_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ruc_number` varchar(15) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `banck_certificate_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`instructor_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `instructor_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor`
--

LOCK TABLES `instructor` WRITE;
/*!40000 ALTER TABLE `instructor` DISABLE KEYS */;
INSERT INTO `instructor` VALUES (1,'1001580396001','Cosme Ortega','0999440944','mc.ortega@utn.edu.ec',NULL,'2025-01-23 19:27:17','2025-01-23 19:27:17',NULL,'sin registro'),(2,NULL,'Luis Flores ','0967248841','lhfloresc@utn.edu.ec',NULL,'2026-10-27 19:49:37','2026-10-27 19:49:37',NULL,';55');
/*!40000 ALTER TABLE `instructor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructor_certificate`
--

DROP TABLE IF EXISTS `instructor_certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor_certificate` (
  `instructor_certificate_id` int NOT NULL AUTO_INCREMENT,
  `instructor_id` int DEFAULT NULL,
  `certificate_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`instructor_certificate_id`),
  KEY `instructor_id` (`instructor_id`),
  KEY `certificate_id` (`certificate_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `instructor_certificate_ibfk_4` FOREIGN KEY (`instructor_id`) REFERENCES `instructor` (`instructor_id`),
  CONSTRAINT `instructor_certificate_ibfk_5` FOREIGN KEY (`certificate_id`) REFERENCES `certificate` (`certificate_id`),
  CONSTRAINT `instructor_certificate_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor_certificate`
--

LOCK TABLES `instructor_certificate` WRITE;
/*!40000 ALTER TABLE `instructor_certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructor_certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modality`
--

DROP TABLE IF EXISTS `modality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modality` (
  `modality_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`modality_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `modality_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modality`
--

LOCK TABLES `modality` WRITE;
/*!40000 ALTER TABLE `modality` DISABLE KEYS */;
INSERT INTO `modality` VALUES (1,'Virtual','Modalidad Virtual','2024-10-05 17:36:51','2024-10-05 17:36:51',1),(2,'Presencial','Modalidad Presencial','2024-10-05 17:36:51','2024-10-05 17:36:51',1),(3,'Hibrida','Modalidad Virtual/Presencial','2024-10-05 17:36:51','2024-10-05 17:36:51',1);
/*!40000 ALTER TABLE `modality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant`
--

DROP TABLE IF EXISTS `participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant` (
  `participant_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cid` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `participant_type_id` int DEFAULT NULL,
  `degree` varchar(100) DEFAULT NULL,
  `degree_level` int DEFAULT NULL,
  `certificate_required` tinyint(1) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `enrolled` tinyint(1) DEFAULT NULL,
  `registered` tinyint(1) DEFAULT NULL,
  `approval` tinyint(1) DEFAULT NULL,
  `total_payment` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `participant_type_id` (`participant_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_ibfk_1` FOREIGN KEY (`participant_type_id`) REFERENCES `participant_type` (`participant_type_id`) ON DELETE SET NULL,
  CONSTRAINT `participant_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant`
--

LOCK TABLES `participant` WRITE;
/*!40000 ALTER TABLE `participant` DISABLE KEYS */;
INSERT INTO `participant` VALUES (1,'ARMAS GARCIA PAUL ALEXANDER',1004168942,NULL,'0998948341','IBARRA','SIN REGISTRO',4,NULL,NULL,0,'',1,1,1,80.00,'2025-01-20 15:58:06','2025-01-20 15:58:06',NULL,1),(2,'ANDRADE POTOSI JUAN CARLOS',401535000,NULL,'sin registro','Ibarrra','no registrado',1,NULL,NULL,0,'sin registro',1,1,1,130.00,'2025-01-23 19:51:28','2025-01-23 19:51:28',NULL,1),(3,'BENAVIDES FLORES ALVARO FERNANDO',1003566815,NULL,'sin registro','Ibarra','sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:19:37','2025-01-23 20:19:37',NULL,1),(4,'BENAVIDES SANCHEZ CARLOS ANDRES',1004134977,NULL,'sin registro','Ibarra','sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:41','2025-01-23 20:25:41',NULL,1),(5,'CADENA LEMA HÉCTOR DARIO',1004562193,NULL,'sin registro','Ibarra','sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:41','2025-01-23 20:25:41',NULL,1),(6,'CARRERA VALENCIA JHIMMY ANDRES',1003202841,NULL,'sin registro',NULL,'sin registro',1,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:42','2025-01-23 20:25:42',NULL,1),(7,'CORAL PAZMIÑO MILTON SANTIAGO',1002340576,NULL,'sin registro',NULL,'sin registro',4,NULL,NULL,0,NULL,1,1,1,130.00,'2025-01-23 20:25:42','2025-01-23 20:25:42',NULL,1),(8,'DOMINGUEZ PASQUEL ANDREA KAROLINA',1003671094,NULL,'sin registro',NULL,'sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:42','2025-01-23 20:25:42',NULL,1),(9,'ICHAU ICHAÚ CRISTIAN VINICIO',1003834866,NULL,'sin registro',NULL,'sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:43','2025-01-23 20:25:43',NULL,1),(10,'INUCA GONZA CYNTIA MARIBEL',1003243639,NULL,'sin registro',NULL,'sin registro',2,NULL,NULL,0,NULL,1,1,1,80.00,'2025-01-23 20:25:43','2025-01-23 20:25:43',NULL,1),(11,'JIMENEZ TABANGO LUIS DAVID ',1003817515,NULL,'sin registro','Otavalo','sin registro',1,NULL,NULL,1,NULL,1,1,0,80.00,'2025-02-11 17:23:25','2025-02-11 17:23:25',NULL,1),(12,'LEON VALLEJOS PABLO VINICIO',1003230388,NULL,'sin registro','Ibarra','sin registro',1,NULL,NULL,1,NULL,1,1,1,80.00,'2025-02-11 17:23:26','2025-02-11 17:23:26',NULL,1),(13,'MEDIAVILLA BORJA EDWIN SEBASTIAN',1004563324,NULL,'sin registro','Otavalo','sin registro',1,NULL,NULL,1,NULL,1,1,0,80.00,'2025-02-11 17:23:26','2025-02-11 17:23:26',NULL,1),(14,'OVIEDO PERUGACHI DARIO FERNANDO',1003752084,NULL,'sin registro','Ibarra','sin registro',1,NULL,NULL,1,NULL,1,1,1,80.00,'2025-02-11 17:23:27','2025-02-11 17:23:27',NULL,1),(15,'PALACIOS OCHOA LUIS FERNANDO',1003066535,NULL,'sin registro','Ibarra','sin registro',1,NULL,NULL,1,NULL,1,1,1,80.00,'2025-02-11 17:23:27','2025-02-11 17:23:27',NULL,1),(16,'RODRIGUEZ BAQUE KAREN ELIZABETH',1003668876,NULL,'sin registro','Cotacachi','sin registro',1,NULL,NULL,1,NULL,1,1,1,80.00,'2025-02-11 17:23:27','2025-02-11 17:23:27',NULL,1),(17,'ROSERO CUASPA FREDDY MARLON',1001987989,NULL,'sin registro','Ibarra','sin registro',1,NULL,NULL,1,NULL,1,1,1,80.00,'2025-02-11 17:23:27','2025-02-11 17:23:27',NULL,1),(18,'SANCHEZ PILLAJO ROMEL DANIEL',1754247722,NULL,'sin registro','Cayambe','sin registro',1,NULL,NULL,1,NULL,1,1,0,80.00,'2025-02-11 17:23:28','2025-02-11 17:23:28',NULL,1),(19,'VEGA VEGA ARMANDO',1002160693,NULL,'sin registro','Ibarra','sin registro',4,NULL,NULL,1,NULL,1,1,1,130.00,'2025-02-11 17:23:28','2025-02-11 17:23:28',NULL,1),(20,'ATUPAÑA CEPEDA DYLAN ALEXANDER',1004235634,'dylanatupana05@gmail.com','0989928352','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(21,'CANO CANDO CRISTHIAN ALEXANDER',401655147,'cris24canocando@gmail.com','0963610427','Tulcán','Telconet Latam',4,'CITEL',NULL,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(22,'CARLOSAMA CHUGA ALDO DANIEL',1004129977,'adcarlosamac1@utn.edu.ec','0978694796','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(23,'CASTILLO VALENCIA WENDY WALESKA',850900895,'waleskacv24@gmail.com','0959984318','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(24,'CHUCURI MUGMAL KIMBERLY DANIELA',1050223948,'kimberly11daniela2002@gmail.com','0998118827','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(25,'CHULDE LORA BRYAN ALEXANDER',1005056575,'bryanchulde1@gmail.com','0967814047','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(26,'Cordova Yamberla Sisa Gissela',1004923759,'cordovagisela387@gmail.com','0939579499','Atuntaqui','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(27,'FARINANGO TALLANA WILMER DAVID',1727464677,'david_farinango@outlook.com','0997335006','Cayambe','Universidad Técnica del Norte',1,'CITEL',8,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(28,'GUALAVISI IMBAQUINGO HANS PERCY',1050172939,'hans_percy@hotmail.com','0962864885','Cayambe','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(29,'Guerrón Torres Steeven Mauricio',401630777,'smguerront@utn.edu.ec','0995340298','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(30,'Ipiales Jingo Marlon Emanuel',1004382691,'marlonipiales551@gmail.com','0983557938','Quito','Universidad Técnica del Norte',2,'CITEL',NULL,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(31,'MENDEZ RODRIGUEZ ALEXIS DANIEL',1050107299,'alxismendzci@gmail.com','0982516014','Ibarra','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(32,'NARVÁEZ SIMBAÑA MARLON BLADIMIR',1004170153,'narvaezmarlon1@gmail.com','0986088119','Atuntaqui','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(33,'NASTACUAZ PADILLA PABLO ALEXANDER',1004766737,'panastacuazp@gmail.com','0997179544','IBARRA','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(34,'QUISHPE FLORES EVELYN SHAKIRA',1050356045,'eveshakira0206@gmail.com','0993094039','Ibarra','BRIDGE TELECOM',2,'CITEL',NULL,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:04','2026-10-29 19:09:04',NULL,1),(35,'SÁNCHEZ QUISHPE DAMIÁN JEFFERSON',1004043988,'damianjeffersonsanchez@gmail.com','0981766641','Cotacachi','Universidad Técnica del Norte',1,'CITEL',7,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:05','2026-10-29 19:09:05',NULL,1),(36,'VIVAS RODRÍGUEZ BRAYAN EDUARDO',401811344,'brayanv@hotmail.es','0968680075','TULCÁN','TELCONET',2,'CIELE',NULL,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:05','2026-10-29 19:09:05',NULL,1),(37,'YACELGA PUPIALES YULLI CAROLINA',1004530141,'ycyacelgap@gmail.com','0982813044','Ibarra','Universidad Técnica del Norte',1,'CITEL',8,NULL,NULL,1,1,0,0.00,'2026-10-29 19:09:05','2026-10-29 19:09:05',NULL,1);
/*!40000 ALTER TABLE `participant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_info_utn`
--

DROP TABLE IF EXISTS `participant_info_utn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_info_utn` (
  `participant_id` int NOT NULL,
  `info_utn_id` int NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`info_utn_id`),
  KEY `info_utn_id` (`info_utn_id`),
  KEY `participant_info_utn_created_by_foreign_idx` (`created_by`),
  CONSTRAINT `participant_info_utn_created_by_foreign_idx` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `participant_info_utn_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_info_utn_ibfk_2` FOREIGN KEY (`info_utn_id`) REFERENCES `info_utn` (`info_utn_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_info_utn`
--

LOCK TABLES `participant_info_utn` WRITE;
/*!40000 ALTER TABLE `participant_info_utn` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant_info_utn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_payment`
--

DROP TABLE IF EXISTS `participant_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_payment` (
  `participant_payment_id` int NOT NULL AUTO_INCREMENT,
  `participant_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`participant_payment_id`),
  KEY `participant_id` (`participant_id`),
  KEY `payment_id` (`payment_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_payment_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `participant` (`participant_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_payment_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`) ON DELETE CASCADE,
  CONSTRAINT `participant_payment_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_payment`
--

LOCK TABLES `participant_payment` WRITE;
/*!40000 ALTER TABLE `participant_payment` DISABLE KEYS */;
INSERT INTO `participant_payment` VALUES (1,1,1,'2025-02-04 19:28:41','2025-02-04 19:28:41',NULL),(2,2,2,'2025-02-04 19:29:26','2025-02-04 19:29:26',NULL),(3,3,3,'2025-02-04 19:30:03','2025-02-04 19:30:03',NULL),(4,4,4,'2025-02-04 19:30:51','2025-02-04 19:30:51',NULL),(5,13,25,'2026-11-05 17:40:47','2026-11-05 17:40:47',NULL),(6,20,26,'2026-11-05 17:42:30','2026-11-05 17:42:30',NULL),(7,21,27,'2026-11-05 20:24:15','2026-11-05 20:24:15',NULL);
/*!40000 ALTER TABLE `participant_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_type`
--

DROP TABLE IF EXISTS `participant_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_type` (
  `participant_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`participant_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `participant_type_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_type`
--

LOCK TABLES `participant_type` WRITE;
/*!40000 ALTER TABLE `participant_type` DISABLE KEYS */;
INSERT INTO `participant_type` VALUES (1,'Estudiante Pregrado UTN','Activo','2025-01-20 15:36:59','2025-01-20 15:36:59',NULL),(2,'Egresado UTN','Activo','2025-01-20 15:37:11','2025-01-20 15:37:11',NULL),(3,'Estudiante Posgrado UTN','Activo','2025-01-20 15:37:26','2025-01-20 15:37:26',NULL),(4,'Particular','Activo','2025-01-20 15:37:50','2025-01-20 15:37:50',NULL),(5,'Docente UTN','Activo','2025-01-20 15:38:01','2025-01-20 15:38:01',NULL),(6,'Graduado UTN','Activo','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(7,'Administrativo UTN','Activo','2026-11-08 17:39:53','2026-11-08 17:39:53',NULL),(8,'Estudiante Pregrado UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(9,'Estudiante Posgrado UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(10,'Egresado UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(11,'Graduado UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(12,'Docente UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(13,'Administrativo UTN','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL),(14,'Particular','Inactivo','2026-11-08 18:49:29','2026-11-08 18:49:29',NULL);
/*!40000 ALTER TABLE `participant_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `payer_cid_ruc` varchar(20) DEFAULT NULL,
  `payer_name` varchar(255) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT '0.00',
  `iva` decimal(10,2) DEFAULT '0.00',
  `description` text,
  `amount` decimal(10,2) DEFAULT NULL,
  `project_code` varchar(50) DEFAULT '0607',
  `course_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`payment_type_id`) REFERENCES `payment_type` (`payment_type_id`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,NULL,NULL,NULL,NULL,0.00,0.00,'Pago Curso',100.00,'0607',NULL,1,'2025-02-04 19:28:41','2025-02-04 19:28:41',NULL),(2,NULL,NULL,NULL,NULL,0.00,0.00,'pago curso',80.00,'0607',NULL,1,'2025-02-04 19:29:26','2025-02-04 19:29:26',NULL),(3,NULL,NULL,NULL,NULL,0.00,0.00,'pago curso',80.00,'0607',NULL,1,'2025-02-04 19:30:03','2025-02-04 19:30:03',NULL),(4,NULL,NULL,NULL,NULL,0.00,0.00,'pago curso\n',80.00,'0607',NULL,1,'2025-02-04 19:30:51','2025-02-04 19:30:51',NULL),(5,'SERIE','2026-11-05','SERIE','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(6,'1','2026-11-05','1','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(7,'2','2026-11-05','2','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(8,'3','2026-11-05','3','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(9,'4','2026-11-05','4','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(10,'5','2026-11-05','5','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(11,'6','2026-11-05','6','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(12,'7','2026-11-05','7','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(13,'8','2026-11-05','8','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(14,'9','2026-11-05','9','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(15,'10','2026-11-05','10','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(16,'11','2026-11-05','11','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(17,'12','2026-11-05','12','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(18,'13','2026-11-05','13','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(19,'14','2026-11-05','14','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(20,'15','2026-11-05','15','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(21,'16','2026-11-05','16','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(22,'17','2026-11-05','17','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(23,'18','2026-11-05','18','',60.00,9.00,NULL,69.00,'0607',26,1,'2026-11-05 15:24:40','2026-11-05 15:24:40',NULL),(24,'1112220202020220','2026-11-05','110000000','MEDIAVILLA BORJA EDWIN SEBASTIAN',60.00,9.00,'Pago matrícula - Factura 1112220202020220',69.00,'0607',27,1,'2026-11-05 17:38:48','2026-11-05 17:38:48',NULL),(25,'100100100','2026-11-05','10','MEDIAVILLA BORJA EDWIN SEBASTIAN',60.00,9.00,'Pago matrícula - Factura 100100100',69.00,'0607',27,1,'2026-11-05 17:40:47','2026-11-05 17:40:47',NULL),(26,'2000200202','2026-11-05','10010000000','ATUPAÑA CEPEDA PADRE',60.00,9.00,'Pago matrícula - Factura 2000200202',69.00,'0607',27,1,'2026-11-05 17:42:30','2026-11-05 17:42:30',NULL),(27,'115050505','2026-11-05','110000000','CANO CANDO CRISTHIAN ALEXANDER',69.57,10.43,'Pago matrícula - Factura 115050505',80.00,'0607',27,1,'2026-11-05 20:24:15','2026-11-05 20:24:15',NULL);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_type`
--

DROP TABLE IF EXISTS `payment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_type` (
  `payment_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`payment_type_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `payment_type_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_type`
--

LOCK TABLES `payment_type` WRITE;
/*!40000 ALTER TABLE `payment_type` DISABLE KEYS */;
INSERT INTO `payment_type` VALUES (1,'Efectivo','2025-02-04 19:20:43','2025-02-04 19:20:43',NULL),(2,'Tarjeta','2025-02-04 19:20:52','2025-02-04 19:20:52',NULL),(3,'Transferencia','2025-02-04 19:20:59','2025-02-04 19:20:59',NULL),(4,'Dos Pagos','2025-02-04 19:21:04','2025-02-04 19:21:04',NULL);
/*!40000 ALTER TABLE `payment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `permission_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'Dashboard','Vista Dashboard','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(2,'Configuracion','Vista Configuracion','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(3,'Detalles','Vista Detalles','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(4,'Auditoria','Vista Auditoria','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(5,'Roles','Vista Roles','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(6,'Permisos','Vista Permisos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(7,'Pago','Vista Pago','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(8,'Tipo de Pago','Vista Tipo de Pago','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(9,'Convenios','Vista Convenios','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(10,'Activos','Vista Activos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(11,'Detalle de Valores','Vista Detalle de Valores','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(12,'Curso','Vista Curso','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(13,'Participante','Vista Participante','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(14,'Capítulos','Vista Capítulos','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(15,'Usuarios','Vista Usuarios','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(16,'Detalles Test','Vista Dashboard','Inactivo','2024-09-30 14:22:21','2024-09-30 14:22:21',1),(17,'Gestionar cursos','Crear y administrar el catálogo, ediciones, planificación y reportes académicos de cursos.','Activo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(18,'Gestionar pagos','Consultar y administrar pagos, comprobantes y reportes de facturación.','Activo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(19,'Consultar dashboard','Consultar el tablero estadístico y el reporte anual sin acceder a funciones de edición.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(20,'Administrar usuarios y roles','Crear cuentas, asignar roles y administrar permisos.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(21,'Administrar datos maestros','Mantener tipos de participante, pagos, instructores y catálogos del sistema.','Inactivo','2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(22,'Consultar información','Consultar cursos, participantes, usuarios del sistema, facturación y dashboard, sin modificar registros.','Activo','2026-11-10 23:01:28','2026-11-10 23:01:28',NULL);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `status` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `role_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrador','Administración completa del sistema y sus datos maestros.','Activo','2024-10-05 17:36:51','2024-10-05 17:36:51',1),(2,'Gestor académico y financiero','Gestiona cursos, ediciones, participantes, pagos e informes.','Inactivo','2026-05-08 11:30:52','2026-05-08 11:30:52',1),(3,'Consulta','Consulta información autorizada sin modificarla.','Inactivo','2026-11-09 17:43:04','2026-11-09 17:43:04',NULL),(4,'Visor','Consulta cursos, participantes, usuarios, facturación e informes sin modificar datos.','Activo','2026-11-11 01:18:28','2026-11-11 01:18:28',NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `role_permission_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int DEFAULT NULL,
  `permission_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`role_permission_id`),
  KEY `role_id` (`role_id`),
  KEY `permission_id` (`permission_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `role_permission_ibfk_4` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `role_permission_ibfk_5` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`permission_id`),
  CONSTRAINT `role_permission_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,1,17,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(2,1,18,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(22,2,17,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(23,2,18,'2026-11-09 18:07:04','2026-11-09 18:07:04',NULL),(25,3,1,'2026-11-10 22:11:09','2026-11-10 22:11:09',NULL),(26,3,2,'2026-11-10 22:11:09','2026-11-10 22:11:09',NULL),(27,3,3,'2026-11-10 22:11:09','2026-11-10 22:11:09',NULL),(28,1,22,'2026-11-10 23:01:28','2026-11-10 23:01:28',NULL),(29,3,22,'2026-11-10 23:01:28','2026-11-10 23:01:28',NULL),(30,4,22,'2026-11-11 01:18:28','2026-11-11 01:18:28',NULL);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `days` varchar(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`schedule_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,'2-3-4','19:30:00','21:30:00','2025-01-20 16:00:42','2025-01-20 16:00:42',NULL,NULL);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `users_role_id_foreign_idx` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Joan Pastillo','jeipige@gmail.com','Ibarra','$2a$08$giP9/76yGnEfjOV8lW9CW.GEP8qus9OFT8/lejuyqOF9iM1xB9OMu','0','2024-10-05 17:36:51','2024-10-05 17:36:51',1),(2,'Luis Flores','lhfloresc@utn.edu.ec','Ibarra','$2a$10$xIVx9gDXongBEf7PFe7iKORj62J/XuquuMjzbKpnFIwweeLHpyFWG','1','2026-04-24 11:38:59','2026-04-24 11:38:59',1),(3,'Usuario Prueba','prueba@test.com','Ibarra','$2a$08$zOq/ofAokYX.WtIvRf9ACea9dUFDJ5i7iy4gE2Y0zJ88Vw5KVfklC','0','2026-05-08 16:17:07','2026-05-08 16:17:07',4),(4,'Usuario Prueba2','example@gmail.com','Ibarra','$2a$08$HVLPFFYxjgEs3Ysu38YMrehhkwEO0mc04KiEru172MFAwGA2ILz2i','0','2026-05-08 16:24:46','2026-05-08 16:24:46',4),(5,'Usuario 3','email@email.com','Ibarra','$2a$08$w/yLOSWZVZPYvkDdG9VEl.RKEw7HMMHffpVfYghthtP/5DI/anOUW','0','2026-05-08 16:36:48','2026-05-08 16:36:48',4),(6,'Usuario Ejemplo','luis2001dc@gmail.com','Cotacachi','$2a$10$FpdWlmTTq68ZeBeRK20bIOvcFDvkGGjgkvRPuPxhzm4NWpYGGfS0m','1','2026-11-10 22:08:00','2026-11-10 22:08:00',4);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'utn_cms'
--

--
-- Dumping routines for database 'utn_cms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-10 20:33:45
